#include <stdio.h>
#include <stdlib.h>

#include "md5.h"

int main() {

	char md5_str[MD5_STR_LEN + 1];
	const char* test_str = "XiaLuoHun";
	Compute_string_md5((unsigned char*)test_str, strlen(test_str), md5_str);
	printf("[string - %s] md5 value:\n", test_str);
	printf("%s\n", md5_str);
	
	system("pause");
	return 0;
}