
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>
#include <stdint.h>  
#include <stdio.h>
#include <stdlib.h>

#include "LuoMd5/md5.h"
#include "AES/AES.h"

//#include "defs.h"

unsigned char byte_40B200[] =
{
  0x57, 0x7C, 0xF5, 0x6D, 0x56, 0x96, 0x77, 0x45, 0xB0, 0xBD,
  0xA1, 0xC7, 0x89, 0xA5, 0xAB, 0xDC, 0xF2, 0xF4, 0x4B, 0xFE,
  0xBE, 0xF5, 0xF5, 0x5C, 0x4D, 0x30, 0x42, 0x0F, 0x2B, 0x3B,
  0xE6, 0xCB
};

//void calc_InvS_Box() {
//	unsigned char sbox_inv[256] = { 0 };
//
//	for (int i = 0; i < 256; i++)
//	{
//		unsigned char temp1 = sbox[i];
//		sbox_inv[temp1] = i;
//	}
//}

int main() {

	char md5_str[MD5_STR_LEN + 1];
	const char* test_str = "Enj0y_1t_4_fuuuN";
	Compute_string_md5((unsigned char*)test_str, strlen(test_str), md5_str);
	printf("string:%s\nmd5 value:%s\n", test_str, md5_str);

	const uint8_t szFlag[] = "XiaLuoHun12345675434567876543Hun";
	uint8_t szOut[32] = {};
	uint8_t szOut2[32] = {};

	uint8_t key[] = "\x2F\x65\xB1\xFF\x31\xED\x86\xD0\x9A\x28\x5C\x0F\x40\x48\x05\x9D";
	//aesEncrypt((const uint8_t*)key, 0x10, szFlag, szOut, 0x20);

	byte_40B200[0x10] = 0xF4;
	byte_40B200[0x11] = 0xF2;

	aesDecrypt((const uint8_t*)key, 0x10, byte_40B200, szOut2, 0x20);

	printf("%s\n",(char*)szOut2);

	system("pause");
	return 0;
}
