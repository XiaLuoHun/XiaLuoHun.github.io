# AES
Advanced Encryption Standard

详细介绍参考博客：《[AES算法描述及C语言实现](https://blog.csdn.net/shaosunrise/article/details/80219950)》
