#include "luomenu.h"
#include <QtWidgets/QApplication>

#include "LuoWidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

	//LuoWidget luoWidget;
	//luoWidget.show();

	LuoMenu w;
	w.show();

    return a.exec();
}
