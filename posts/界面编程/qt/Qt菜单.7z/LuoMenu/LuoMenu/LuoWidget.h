#pragma once

#include <QWidget>
#include <QMenu>
#include <QMenuBar>
#include "ui_LuoWidget.h"

#include <QDebug>

class LuoWidget : public QWidget
{
	Q_OBJECT

public:
	LuoWidget(QWidget *parent = Q_NULLPTR);
	~LuoWidget();

public slots:
	void Hover()
	{
		qDebug() << "Hover";
	}
	void Action1()
	{
		qDebug() << "Action1";
	}
	void Action(QAction* act)
	{
		qDebug() << "Action " << act->text();
	}

	void Hovered(QAction* act) 
	{
		//��̬�˵�
		if (act->text() == QStringLiteral("�˵�3"))
		{
			act->menu()->clear();
			act->menu()->addAction(QStringLiteral("�˵�3.1"));
			act->menu()->addAction(QStringLiteral("�˵�3.2"));
			act->menu()->addAction(QStringLiteral("�˵�3.3"));
		}
	}

	void Action1(bool b)
	{
		qDebug() << "Action1 " << b;
	}

	//��ť����¼�
	void Click() 
	{
		//���λ����ʾ�˵�
		m1->exec(QCursor::pos());
	}

private:
	QMenu* m1 = NULL;
	Ui::LuoWidget ui;
};
