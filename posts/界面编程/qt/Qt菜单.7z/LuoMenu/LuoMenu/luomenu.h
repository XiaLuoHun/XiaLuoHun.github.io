#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_luomenu.h"

class LuoMenu : public QMainWindow
{
    Q_OBJECT

public:
    LuoMenu(QWidget *parent = Q_NULLPTR);

private:
    Ui::LuoMenuClass ui;
};
