#include <stdio.h>

void func1();