#include "func1.h"

void func1(){
	printf("func1\n");
}