#include <stdlib.h>
#include <stdio.h>

#include "func1.h"

int main(){
    func1();
	printf("main\n");
	system("pause");
	return 0;
}