#pragma once

#include <QDialog>
#include "ui_XMessageBox.h"

class XMessageBox : public QDialog
{
	Q_OBJECT

public:
	XMessageBox(QWidget *parent = Q_NULLPTR);
	~XMessageBox();

private:
	Ui::XMessageBox ui;
};
