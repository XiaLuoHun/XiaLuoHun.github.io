#pragma once

#include <QDialog>
#include <QThread>
#include "ui_LuoProgressDialog.h"

class LuoProgressDialog : public QDialog
{
	Q_OBJECT

public:
	LuoProgressDialog(QWidget *parent = Q_NULLPTR);
	~LuoProgressDialog();

public slots:
	//0~1000
	void SetPos(int pos);

private:
	Ui::LuoProgressDialog ui;
};
