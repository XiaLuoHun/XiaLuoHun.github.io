#include "XMessageBox.h"

XMessageBox::XMessageBox(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);

	ui.label->setText("Test");

}

XMessageBox::~XMessageBox()
{
}
