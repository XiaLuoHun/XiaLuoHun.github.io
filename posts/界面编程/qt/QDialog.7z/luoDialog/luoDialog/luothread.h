#pragma once

#include <QThread>

class LuoThread : public QThread
{
	Q_OBJECT

public:
	LuoThread();
	~LuoThread();
protected:
	void run();

signals:
	///0~1000
	void SetPos(int pos);
};
