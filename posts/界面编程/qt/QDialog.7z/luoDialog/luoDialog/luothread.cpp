#include "luothread.h"

LuoThread::LuoThread()
{
}

LuoThread::~LuoThread()
{
}

void LuoThread::run()
{
	//ģ������
	for (int i = 0; i <= 1000; i++)
	{
		SetPos(i);
		msleep(5);
	}
}