#include "luodialog.h"
#include <QtWidgets/QApplication>

#include <QDialog>
#include "XMessageBox.h"

#include "luothread.h"
#include "LuoProgressDialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //������
    LuoProgressDialog luoPro;
    //�߳�
    LuoThread luoThread;
    //�źŲ۰�
    QObject::connect(&luoThread, SIGNAL(SetPos(int)), &luoPro, SLOT(SetPos(int)));
    //�����߳�
    luoThread.start();
    //��ʾ�Ի���
    luoPro.exec();

    XMessageBox xBox;
    xBox.exec();

    luoDialog w;
    w.show();

   
    return a.exec();
}
