#include "luodialog.h"

luoDialog::luoDialog(QWidget *parent)
    : QDialog(parent)
{
    ui.setupUi(this);
}
