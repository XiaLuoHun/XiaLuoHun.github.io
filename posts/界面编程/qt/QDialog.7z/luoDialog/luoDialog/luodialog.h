#pragma once

#include <QtWidgets/QDialog>
#include "ui_luodialog.h"

class luoDialog : public QDialog
{
    Q_OBJECT

public:
    luoDialog(QWidget *parent = Q_NULLPTR);

private:
    Ui::luoDialogClass ui;
};
