#pragma once

#include <QtWidgets/QWidget>
#include "ui_luoevent.h"

#include <QKeyEvent>
#include <QMouseEvent>
#include <QResizeEvent>
class LuoEvent : public QWidget
{
    Q_OBJECT

public:
    LuoEvent(QWidget *parent = Q_NULLPTR);

    //����event
    bool event(QEvent* ev);

    //�����¼�
    void keyPressEvent(QKeyEvent* ev);
    void keyReleaseEvent(QKeyEvent* ev);

    //���ڴ�С�ı��¼�
    void resizeEvent(QResizeEvent* re);



private:
    Ui::LuoEventClass ui;
};
