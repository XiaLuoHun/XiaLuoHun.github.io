#pragma once

#include <QtWidgets/QWidget>
#include "ui_luoqt.h"

#include <QDebug>
class luoqt : public QWidget
{
    Q_OBJECT

public:
    luoqt(QWidget *parent = Q_NULLPTR);

public slots:

    void LuoClick();

    void SelChange();

    void ItemEntered(QTableWidgetItem* item);

    void CellEntered(int row, int column);

private:
    Ui::luoqtClass ui;
};
