#include "luoqt.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    luoqt w;
    w.show();
    return a.exec();
}
