#include "ClearJunkCodeDialog.h"

HWND g_hDialog = NULL;

duint g_dStartAddr = 0;
duint g_dSize = 0;

FILE* g_pFile = NULL;
char szFileName[] = ".\\plugins\\LuoJunkCode.txt";

INT_PTR CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
	{
		/*HWND hEdit = ::GetDlgItem(hwndDlg, IDC_EDITJUNKCODE);
		::SetWindowText(hEdit, "��ָ��");*/
		g_pFile = fopen(szFileName, "a+");
		break;
	}
	case WM_CLOSE:
	{
		DestroyWindow(hwndDlg);
		
		if (g_pFile)
		{
			fclose(g_pFile);
		}

		g_hDialog = NULL;
		return true;
		break;
	}
	case WM_COMMAND:
	{
		switch (LOWORD(wParam))
		{
		case BTN_ADDFEATURE:
		{
			AddFeature(hwndDlg);
			break;
		}

		case BTN_CLEARJUNKCODE:
		{
			ClearJunkCode(hwndDlg);
			break;
		}

		case BTN_FILE:
		{
			ClearJunkCodeByFile(hwndDlg);
			break;
		}

		}

		break;
	}
	default:
		break;
	}

	return false;
}

void centerWindow(HWND window)
{
	RECT parentRect;
	RECT windowRect;

	GetWindowRect(GuiGetWindowHandle(), &parentRect);
	GetWindowRect(window, &windowRect);

	int x = parentRect.left + (parentRect.right - parentRect.left) / 2 - (windowRect.right - windowRect.left) / 2;
	int y = parentRect.top + (parentRect.bottom - parentRect.top) / 2 - (windowRect.bottom - windowRect.top) / 2;

	SetWindowPos(window, NULL, x * 1.5, y * 0.4, NULL, NULL, SWP_NOSIZE);
}

void ShowClearJunkDialog(HINSTANCE instance, duint dStart, duint dSize)
{
	if (!g_hDialog)
	{
		g_dStartAddr = dStart;
		g_dSize = dSize;
		g_hDialog = CreateDialog(instance, MAKEINTRESOURCE(IDD_CLEARJUNKDIALOG), GuiGetWindowHandle(), DialogProc);
	}
	
	ShowWindow(g_hDialog, SW_SHOW);
	centerWindow(g_hDialog);
}


void CloseClearJunkDialog()
{
	if (g_hDialog)
	{
		SendMessage(g_hDialog, WM_CLOSE, 0, 0);
	}
		
	g_hDialog = NULL;
}

void AddFeature(HWND hwndDlg)
{
	//��ȡ�༭������
	char szEditBuff[0x1000] = {};
	HWND hEdit = ::GetDlgItem(hwndDlg, IDC_EDITJUNKCODE);
	GetWindowText(hEdit, szEditBuff, sizeof(szEditBuff));

	string strEdit = szEditBuff;

	//����ո�
	ClearSpace(strEdit);

	if (strEdit.length() == 0)
	{
		Script::Gui::Message(Gb2312ToUtf8("ʲô��û��, �㶺����!"));
		return;
	}

	//Ŀ���ַ���
	string strDst = strEdit;

	//�ַ������Ϊ90
	FillNop(strDst);

	//����ļ����Ƿ��Ѵ��ڸ�����
	strEdit += "\n";
	bool bRet = IsFileExisted(g_pFile, strEdit.c_str());
	if (bRet)
	{
		Script::Gui::Message(Gb2312ToUtf8("�������Ѵ���"));
		return;
	}

	//�ƶ��ļ�ָ�뵽�ļ�ĩβ
	fseek(g_pFile, 0, SEEK_END);

	fwrite(strEdit.c_str(), strEdit.length(), 1, g_pFile);
	//fwrite("\n", 1, 1, g_pFile);

	fflush(g_pFile);
	Script::Gui::Message(Gb2312ToUtf8("���������ɹ�"));
}

void ClearJunkCode(HWND hwndDlg)
{
	//��ȡ�༭������
	char szEditBuff[0x1000] = {};
	HWND hEdit = ::GetDlgItem(hwndDlg, IDC_EDITJUNKCODE);
	GetWindowText(hEdit, szEditBuff, sizeof(szEditBuff));

	string strEdit = szEditBuff;

	if (strEdit.length() == 0)
	{
		return;
	}

	//����ո�
	ClearSpace(strEdit);

	//�ڷ���ര�������ָ��
	ClearDisasmCode(strEdit.c_str());

	Script::Gui::Message(Gb2312ToUtf8("��ָ��������"));
}

void ClearDisasmCode(const char* searchpattern)
{
	//Ŀ���ַ���
	string strDst = searchpattern;

	//�ַ������Ϊ90
	FillNop(strDst);

	while (Script::Pattern::SearchAndReplaceMem(g_dStartAddr, g_dSize, searchpattern, strDst.c_str()))
	{
		//ˢ�·������ͼ
		Script::Gui::Refresh();
	}
}

void ClearJunkCodeByFile(HWND hwndDlg)
{
	//�ƶ��ļ�ָ�뵽�ļ�ͷ��
	fseek(g_pFile, 0, SEEK_SET);

	char szSearchPattern[0x1024] = {};
	while (fgets(szSearchPattern, 0x1000, g_pFile))
	{
		duint dSearchPatternLen = strlen(szSearchPattern);
		szSearchPattern[dSearchPatternLen - 1] = '\0';

		ClearDisasmCode(szSearchPattern);
		memset(szSearchPattern, 0, 0x1024);
	}

	Script::Gui::Message(Gb2312ToUtf8("�ļ���ȡ���"));
}

