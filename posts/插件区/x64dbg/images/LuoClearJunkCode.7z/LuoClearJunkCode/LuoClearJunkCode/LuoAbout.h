#pragma once
#include "pluginmain.h"
#include "resource.h"

#include "Common.h"

void ShowAboutDialog(HINSTANCE instance);

void CloseAboutialog();