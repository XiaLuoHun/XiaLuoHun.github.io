//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� LuoClearJunkCode.rc ʹ��
//
#define IDB_PNGMAIN                     101
#define IDD_CLEARJUNKDIALOG             102
#define IDD_DIALOG1                     104
#define IDD_ABOUT                       104
#define IDC_EDITJUNKCODE                1001
#define BTN_ADDFEATURE                  1002
#define BTN_CLEARJUNKCODE               1003
#define BTN_FILE                        1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
