
#include "pluginmain.h"
#define PLUGIN_VERSION 1
#define PLUGIN_NAME "LuoClearJunkCode"

#include "resource.h"

#include "Common.h"

#include "ClearJunkCodeDialog.h"
#include "LuoAbout.h"

//���������ھ��
HWND g_hwndDlg;
//���˵����
int g_hMenu;
//����ര�ھ��
int g_hMenuDisasm;
//���ݴ��ھ��
int g_hMenuDump;
//��ջ���ھ��
int g_hMenuStack;

enum
{
	_ClearJunkCode,
	About
};

HINSTANCE g_hInstance;

int  g_nPluginHandle = 0;

duint g_dModuleBaseAddress = 0;
duint g_dModuleSize = 0;
BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	{
		g_hInstance = (HINSTANCE)hModule;
		g_dModuleBaseAddress = Script::Module::GetMainModuleBase();
		g_dModuleSize = Script::Module::GetMainModuleSize();
	}
		
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

PLUG_EXPORT bool pluginit(PLUG_INITSTRUCT* initStruct)
{
	//������汾�Ÿ�ֵ
	initStruct->pluginVersion = PLUGIN_VERSION;
	//��SDK�汾�Ÿ�ֵ
	initStruct->sdkVersion = PLUG_SDKVERSION;
	//���ò������
	strncpy_s(initStruct->pluginName, Gb2312ToUtf8(PLUGIN_NAME), _TRUNCATE);
	//�õ�������
	g_nPluginHandle = initStruct->pluginHandle;

	return true;
}


PLUG_EXPORT bool plugstop()
{
	//�ر������ָ��Ի���
	CloseClearJunkDialog();
	CloseAboutialog();
	return true;
}

void  CB_STOPDEBUG_Back(CBTYPE cbType, void* callbackInfo)
{
	//�ر������ָ��Ի���
	CloseClearJunkDialog();
	CloseAboutialog();
}

PLUG_EXPORT void plugsetup(PLUG_SETUPSTRUCT* setupStruct)
{
	//��ȡ�����������ھ��
	g_hwndDlg = setupStruct->hwndDlg;
	//��ȡ���˵����
	g_hMenu = setupStruct->hMenu;
	//��ȡ����ര�ھ��
	g_hMenuDisasm = setupStruct->hMenuDisasm;
	//��ȡ���ݴ��ھ��
	g_hMenuDump = setupStruct->hMenuDump;
	//��ȡ��ջ���ھ��
	g_hMenuStack = setupStruct->hMenuStack;

	//����ͼ��
	ICONDATA mainIconData = { 0 };
	HRSRC hResPng = FindResource(g_hInstance, MAKEINTRESOURCE(IDB_PNGMAIN), "PNG");
	if (hResPng != NULL)
	{
		HGLOBAL hResLoad = LoadResource(g_hInstance, hResPng);
		if (hResLoad != NULL)
		{
			mainIconData.data = LockResource(hResLoad);
			mainIconData.size = SizeofResource(g_hInstance, hResPng);

			if (mainIconData.data != NULL && mainIconData.size != 0)
			{
				_plugin_menuseticon(g_hMenu, (const ICONDATA*)&mainIconData);
				_plugin_menuseticon(g_hMenuDisasm, (const ICONDATA*)&mainIconData);
				_plugin_menuseticon(g_hMenuDump, (const ICONDATA*)&mainIconData);
				_plugin_menuseticon(g_hMenuStack, (const ICONDATA*)&mainIconData);
			}
		}
	}

	//������
	_plugin_menuaddentry(g_hMenu, _ClearJunkCode, Gb2312ToUtf8("Clear Junk Code"));
	_plugin_menuaddentry(g_hMenu, About, Gb2312ToUtf8("About"));

	//ע��ص�����
	_plugin_registercallback(g_nPluginHandle, CB_STOPDEBUG, CB_STOPDEBUG_Back);
}

PLUG_EXPORT void CBMENUENTRY(CBTYPE cbType, PLUG_CB_MENUENTRY* info)
{
	switch (info->hEntry)
	{
	case _ClearJunkCode:
	{
		if (DbgIsDebugging())
		{
			duint dSelDisasmAddr = Script::Gui::Disassembly::SelectionGetStart();
			duint dSelBase = Script::Memory::GetBase(dSelDisasmAddr);
			duint dSelSize = Script::Memory::GetSize(dSelDisasmAddr);

			ShowClearJunkDialog(g_hInstance, dSelBase, dSelSize);
		}
		else
		{
			Script::Gui::Message(Gb2312ToUtf8("���һ������"));
		}
		
		break;
	}
	case About:
	{
		ShowAboutDialog(g_hInstance);
		break;
	}
	default:
		break;
	}
}

