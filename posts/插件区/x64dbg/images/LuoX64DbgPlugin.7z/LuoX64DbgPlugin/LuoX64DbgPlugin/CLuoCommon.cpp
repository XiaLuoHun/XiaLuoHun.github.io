#include "CLuoCommon.h"

#include "Common.h"

CLuoCommon::CLuoCommon()
{

}

CLuoCommon::~CLuoCommon()
{

}

void CLuoCommon::DumpQuickSel()
{
	//��ȡ��ǰѡ�е�ַ
	duint dStartAddr = Gui::SelectionGetStart(DumpWindow);

	//��ȡҪѡ��Ĵ�С
	const char szMsg[] = "������Ҫѡ��Ĵ�С";
	duint dSelSize = 0;
	if (Gui::InputValue(Gb2312ToUtf8(szMsg), &dSelSize))
	{
		Gui::Dump::SelectionSet(dStartAddr, dStartAddr + dSelSize - 1);
	}
}

void CLuoCommon::DisasmQuickSelStart()
{
	//��ȡ��ǰѡ�е�ַ
	m_dStartAddr = Gui::SelectionGetStart(DisassemblyWindow);
}

void CLuoCommon::DisasmQuickSelEnd()
{
	//��ȡ��ǰѡ�е�ַ
	m_dEndAddr = Gui::SelectionGetStart(DisassemblyWindow);

	if (m_dStartAddr > m_dEndAddr)
	{
		duint nTemp = m_dStartAddr;
		m_dStartAddr = m_dEndAddr;
		m_dEndAddr = nTemp;
	}

	BASIC_INSTRUCTION_INFO InstInfo;
	DbgDisasmFastAt(m_dEndAddr, &InstInfo);

	Gui::Disassembly::SelectionSet(m_dStartAddr, m_dEndAddr + InstInfo.size - 1);
}

void CLuoCommon::SearchEButton()
{
	//��ȡ��ģ���ַ
	duint dMainModuleBase = Module::GetMainModuleBase();
	//��ȡ��ģ���С
	duint dMainModuleSize = Module::GetMainModuleSize();

	//�����԰�ť�¼�������
	const char szEButtonFeature[] = "8B4C90??894DF0FF75F0EBDFFF55FC5F5E";

	duint dFindAddr = Pattern::FindMem(dMainModuleBase, dMainModuleSize, szEButtonFeature);
	
	if (dFindAddr == 0)
	{
		return;
	}

	duint dReadAddr = dFindAddr + 12;
	//���÷����λ��
	GuiDisasmAt(dReadAddr, 0);
}

