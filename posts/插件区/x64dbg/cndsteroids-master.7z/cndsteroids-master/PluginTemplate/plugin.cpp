#include "plugin.h"
#include <vector>
#include <map>
#include <string>

#define MAX_SIZE 300

using namespace std;

std::map<int, char*> g_LuoMap;

static bool delAllString(int argc, char* argv[])
{
	std::map<int, char*>::iterator it = g_LuoMap.begin();
	for (; it != g_LuoMap.end(); ++it)
	{
		if (it->second != NULL)
		{
			free(it->second);
			it->second = NULL;
		}
	}

	g_LuoMap.clear();

	_plugin_logprintf("[" PLUGIN_NAME "] delAllString Success\n");

	return true;
}

static bool setString(int argc, char* argv[])
{
	/*
	@param index: number to identifie the string.
	@param text: the string to compare. 
	*/

	if (argc != 3) {
		_plugin_logputs("[" PLUGIN_NAME "] Help: setString index, \"string\"\n");
		return false;
	}
	
	char* pszText = NULL;
	int nCode = 0;
	sscanf(argv[1], "%x", &nCode);

	int nLen = sizeof(char) * strlen(argv[2]) + 1;

	if (nLen > MAX_SIZE)
	{
		_plugin_logprintf("[" PLUGIN_NAME "] String too long\n");
		return false;
	}

	pszText = (char *)malloc(nLen);
	if (pszText == NULL)
	{
		_plugin_logprintf("[" PLUGIN_NAME "] setString malloc failed\n");
		return false;
	}

	strcpy(pszText, argv[2]);
	
	//�����Ƿ��Ѵ���
	std::map<int, char*>::iterator it = g_LuoMap.find(nCode);
	if (it != g_LuoMap.end() &&
		strcmp(it->second, argv[2]) == 0)
	{
		_plugin_logputs("[" PLUGIN_NAME "] String already exists\n");
	}
	else if (it != g_LuoMap.end())
	{
		free(it->second);
		it->second = pszText;
	}
	else
	{
		g_LuoMap.insert(pair<int, char*>(nCode, pszText));
	}

	_plugin_logprintf("[" PLUGIN_NAME "] %x = %s was saved\n", nCode, pszText);
	return true;
}

static duint Strcmp(int argc, duint* argv, void* userdata)
{
	/*
	@param memory: memory address with a string.
	@param type: $ANSI or $UNICODE (this variables was setted for the plugin).
	@param index: identifier of the string setted (it's decimal, so.. U need to use a dot in the end of the number).
	
	@return: true if the memory address is a pointer to the string stored.
	*/
	
	char *argparse;
	duint step;
	duint va;

	if (!DbgIsDebugging()) {
		_plugin_logputs("[" PLUGIN_NAME "] You need to be debugging to use this expression functions\n");
		return false;
	} else if (g_LuoMap.empty()) {
		_plugin_logprintf("[" PLUGIN_NAME "] You need to set a string with code %d (use setString)\n", argv[1]);
		return false;
	} else if (argv[1] < 1 && argv[1] > 2) {
		_plugin_logprintf("[" PLUGIN_NAME "] Second argument only supports 1 or 2 (or $ANSI and $UNICODE) to set the string type.\n");
		return false;
	}
	
	argparse = (char *)malloc(sizeof(char)*MAX_SIZE);
	va = argv[0];
	
	step = argv[1];
	for (int i = 0; i < MAX_SIZE; i++) {
		if (!DbgMemIsValidReadPtr(va+(i*step))) {
			_plugin_logprintf("[" PLUGIN_NAME "] Error reading [0x%x+0x%.2x*2]\n", va, i);
			return 0;
		}

		DbgMemRead(va+(i*step), argparse+i, sizeof(char));
		if (*(argparse+i) == '\x00')
			break;
	}

	std::map<int, char*>::iterator it = g_LuoMap.find(argv[2]);
	if (it != g_LuoMap.end() &&
		strcmp(argparse, it->second) == 0)
	{
		_plugin_logputs("[" PLUGIN_NAME "] Condition successful\n");
		return true;
	}

	_plugin_logprintf("[" PLUGIN_NAME "] Index %d not found\n", argv[2]);
	return false;

}

static duint Strstr(int argc, duint* argv, void* userdata)
{
	/*
	@param memory: memory address with a string.
	@param type: $ANSI or $UNICODE (this variables was setted for the plugin).
	@param index: identifier of the string setted (it's decimal, so.. U need to use a dot in the end of the number).

	@return: true if the memory address is a pointer to the string stored.
	*/

	char* argparse;
	duint step;
	duint va;

	if (!DbgIsDebugging()) {
		_plugin_logputs("[" PLUGIN_NAME "] You need to be debugging to use this expression functions\n");
		return false;
	}
	else if (g_LuoMap.empty()) {
		_plugin_logprintf("[" PLUGIN_NAME "] You need to set a string with code %d (use setString)\n", argv[1]);
		return false;
	}
	else if (argv[1] < 1 && argv[1] > 2) {
		_plugin_logprintf("[" PLUGIN_NAME "] Second argument only supports 1 or 2 (or $ANSI and $UNICODE) to set the string type.\n");
		return false;
	}

	argparse = (char*)malloc(sizeof(char) * MAX_SIZE);
	va = argv[0];

	step = argv[1];
	for (int i = 0; i < MAX_SIZE; i++) {
		if (!DbgMemIsValidReadPtr(va + (i * step))) {
			_plugin_logprintf("[" PLUGIN_NAME "] Error reading [0x%x+0x%.2x*2]\n", va, i);
			return 0;
		}

		DbgMemRead(va + (i * step), argparse + i, sizeof(char));
		if (*(argparse + i) == '\x00')
			break;
	}

	std::map<int, char*>::iterator it = g_LuoMap.find(argv[2]);
	if (it != g_LuoMap.end() &&
		strstr(argparse, it->second) != NULL)
	{
		_plugin_logputs("[" PLUGIN_NAME "] Condition successful\n");
		return true;
	}

	_plugin_logprintf("[" PLUGIN_NAME "] Index %d not found\n", argv[2]);
	return false;

}

//Initialize your plugin data here.
bool pluginInit(PLUG_INITSTRUCT* initStruct)
{
	if (!_plugin_registercommand(pluginHandle, "setString", setString, false))
		_plugin_logputs("[" PLUGIN_NAME "] Error registering the \"setString\" command!");

	if (!_plugin_registercommand(pluginHandle, "delAllString", delAllString, false))
		_plugin_logputs("[" PLUGIN_NAME "] Error registering the \"delString\" command!");
	
    if (!_plugin_registerexprfunction(pluginHandle, PLUGIN_NAME ".Strcmp", 3, Strcmp, nullptr))
		_plugin_logputs("[" PLUGIN_NAME "] Error register the \"" PLUGIN_NAME ".Strcmp\" expression function!");
	
	if (!_plugin_registerexprfunction(pluginHandle, PLUGIN_NAME ".Strstr", 3, Strstr, nullptr))
		_plugin_logputs("[" PLUGIN_NAME "] Error register the \"" PLUGIN_NAME ".Strstr\" expression function!");

	DbgCmdExecDirect("$ANSI=1");
	DbgCmdExecDirect("$UNICODE=2");

    return true; //Return false to cancel loading the plugin.
}

//Deinitialize your plugin data here (clearing menus optional).
bool pluginStop()
{
    _plugin_unregistercommand(pluginHandle, "setString");
	_plugin_unregistercommand(pluginHandle, "delAllString");
	_plugin_unregisterexprfunction(pluginHandle, PLUGIN_NAME ".Strcmp");
	_plugin_unregisterexprfunction(pluginHandle, PLUGIN_NAME ".Strstr");

	//�ͷſռ�
	std::map<int, char*>::iterator it = g_LuoMap.begin();
	for (; it != g_LuoMap.end(); ++it)
	{
		if (it->second != NULL)
		{
			free(it->second);
			it->second = NULL;
		}
	}

	g_LuoMap.clear();

    return true;
}