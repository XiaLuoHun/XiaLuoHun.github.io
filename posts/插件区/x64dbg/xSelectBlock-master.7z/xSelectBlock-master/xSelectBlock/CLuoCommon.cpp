#include "CLuoCommon.h"


CLuoCommon::CLuoCommon()
{

}

CLuoCommon::~CLuoCommon()
{

}

void CLuoCommon::DisasmQuickSelStart()
{
	//��ȡ��ǰѡ�е�ַ
	m_dStartAddr = Gui::SelectionGetStart(DisassemblyWindow);
}

void CLuoCommon::DisasmQuickSelEnd()
{
	//��ȡ��ǰѡ�е�ַ
	m_dEndAddr = Gui::SelectionGetStart(DisassemblyWindow);

	if (m_dStartAddr > m_dEndAddr)
	{
		duint nTemp = m_dStartAddr;
		m_dStartAddr = m_dEndAddr;
		m_dEndAddr = nTemp;
	}

	BASIC_INSTRUCTION_INFO InstInfo;
	DbgDisasmFastAt(m_dEndAddr, &InstInfo);

	Gui::Disassembly::SelectionSet(m_dStartAddr, m_dEndAddr + InstInfo.size - 1);
}


