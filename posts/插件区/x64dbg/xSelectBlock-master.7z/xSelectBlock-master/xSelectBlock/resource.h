//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� selectDialog.rc ʹ��
//
#define IDD_SelectBlock                 9
#define IDB_PNG1                        105
#define IDB_PNGMAIN                     105
#define IDC_START_EDIT                  1001
#define IDC_END_RADIO                   1002
#define IDC_END_EDIT                    1003
#define IDC_RADIO2                      1004
#define IDC_LEN_RADIO                   1004
#define IDC_LENGTH_EDIT                 1005
#define IDC_HEX_RADIO                   1006
#define IDC_DEC_RADIO                   1007
#define ID_GROUPBOX                     1008
#define IDC_BUTTON_OK                   1011
#define IDC_BUTTON_CANCEL               1012
#define IDC_OCT_RADIO                   1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
