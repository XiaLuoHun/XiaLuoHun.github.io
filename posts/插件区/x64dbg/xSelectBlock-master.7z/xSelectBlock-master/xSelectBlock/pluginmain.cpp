#include "pluginmain.h"
#include "plugin.h"

#include "resource.h"

int pluginHandle;
HWND hwndDlg;
int hMenu;
int hMenuDisasm;
int hMenuDump;
int hMenuStack;

extern HINSTANCE instance;

PLUG_EXPORT bool pluginit(PLUG_INITSTRUCT* initStruct)
{
    initStruct->pluginVersion = PLUGIN_VERSION;
    initStruct->sdkVersion = PLUG_SDKVERSION;
    strncpy_s(initStruct->pluginName, PLUGIN_NAME, _TRUNCATE);
    pluginHandle = initStruct->pluginHandle;
    return pluginInit(initStruct);
}

PLUG_EXPORT bool plugstop()
{
    pluginStop();
    return true;
}

PLUG_EXPORT void plugsetup(PLUG_SETUPSTRUCT* setupStruct)
{
    hwndDlg = setupStruct->hwndDlg;
    hMenu = setupStruct->hMenu;
    hMenuDisasm = setupStruct->hMenuDisasm;
    hMenuDump = setupStruct->hMenuDump;
    hMenuStack = setupStruct->hMenuStack;
    pluginSetup();

	//����ͼ��
	ICONDATA mainIconData = { 0 };
	HRSRC hResPng = FindResource(instance, MAKEINTRESOURCE(IDB_PNGMAIN), "PNG");
	if (hResPng != NULL)
	{
		HGLOBAL hResLoad = LoadResource(instance, hResPng);
		if (hResLoad != NULL)
		{
			mainIconData.data = LockResource(hResLoad);
			mainIconData.size = SizeofResource(instance, hResPng);

			if (mainIconData.data != NULL && mainIconData.size != 0)
			{
				_plugin_menuseticon(hMenu, (const ICONDATA*)&mainIconData);
				_plugin_menuseticon(hMenuDisasm, (const ICONDATA*)&mainIconData);
				_plugin_menuseticon(hMenuDump, (const ICONDATA*)&mainIconData);
				_plugin_menuseticon(hMenuStack, (const ICONDATA*)&mainIconData);
			}
		}
	}

}