#pragma once
#include "pluginmain.h"

using namespace Script;
using namespace Gui;
class CLuoCommon
{
public:
	CLuoCommon();
	virtual ~CLuoCommon();

public:
	//����ѡ��
	//����ര��
	void DisasmQuickSelStart();
	void DisasmQuickSelEnd();

private:
	duint m_dStartAddr = 0;
	duint m_dEndAddr = 0;
};
