
#include "Common.h"
#include <stdio.h>

DWORD Bin_Search(BYTE * pSourceArrary, DWORD dwSourceLen, char* conditionCode)
{
	char tempStr[3] = { 0 };
	BYTE nValude = 0;
	for (int i=0;i<=dwSourceLen-strlen(conditionCode)/2;i++)
	{
		//��ȡǰ�����ַ�
		strncpy_s(tempStr, conditionCode, 2);
		sscanf_s(tempStr, "%x", &nValude);
		if (pSourceArrary[i] == nValude)
		{
			bool isFind = true;
			for (int k=0,m=0;k< strlen(conditionCode);k+=2,m++)
			{
				//��ȡ�����ַ�
				strncpy_s(tempStr, conditionCode+k, 2);
				if (strcmp(tempStr,"??")==0)
				{
					continue;
				}
				sscanf_s(tempStr, "%x", &nValude);
				if (pSourceArrary[i+m]!= nValude)
				{
					isFind = false;
					break;
				}
			}
			if (isFind)
			{
				return i;
			}
		}
	}
	return 0;
}

DWORD Bin_Search(BYTE * pSourceArrary, DWORD dwSourceLen, BYTE *pTargetArray, DWORD dwTargetLen)
{
	for (int i = 0; i <= dwSourceLen - dwTargetLen; i++)
	{
		if (pSourceArrary[i] == pTargetArray[0])
		{
			BOOL isFind = TRUE;
			for (int j = 0; j < dwTargetLen; j++)
			{
				if (pSourceArrary[i + j] != pTargetArray[j])
				{
					isFind = FALSE;
					break;
				}
			}
			if (isFind)
			{
				return i;
			}
		}
	}
	return 0;
}



int Str_IsEndWith(const char *str1, char *str2)
{
	if (str1 == NULL || str2 == NULL)
		return -1;
	int len1 = strlen(str1);
	int len2 = strlen(str2);
	if ((len1 < len2) || (len1 == 0 || len2 == 0))
		return -1;
	while (len2 >= 1)
	{
		if (str2[len2 - 1] != str1[len1 - 1])
			return 0;
		len2--;
		len1--;
	}
	return 1;
}

bool Str_IsBeginWith(const char *str1, const char *str2)
{
	size_t lenpre = strlen(str1),
		lenstr = strlen(str2);
	return lenstr < lenpre ? false : strncmp(str1, str2, lenpre) == 0;
}


char* Gb2312ToUtf8(const char* gb2312)
{
	int len = MultiByteToWideChar(CP_ACP, 0, gb2312, -1, NULL, 0);
	wchar_t* wstr = new wchar_t[len + 1];
	memset(wstr, 0, len + 1);
	MultiByteToWideChar(CP_ACP, 0, gb2312, -1, wstr, len);
	len = WideCharToMultiByte(CP_UTF8, 0, wstr, -1, NULL, 0, NULL, NULL);
	char* str = new char[len + 1];
	memset(str, 0, len + 1);
	WideCharToMultiByte(CP_UTF8, 0, wstr, -1, str, len, NULL, NULL);
	if (wstr) delete[] wstr;
	return str;
}


char* Utf8ToGb2312(const char* utf8)
{
	int len = MultiByteToWideChar(CP_UTF8, 0, utf8, -1, NULL, 0);
	wchar_t* wstr = new wchar_t[len + 1];
	memset(wstr, 0, len + 1);
	MultiByteToWideChar(CP_UTF8, 0, utf8, -1, wstr, len);
	len = WideCharToMultiByte(CP_ACP, 0, wstr, -1, NULL, 0, NULL, NULL);
	char* str = new char[len + 1];
	memset(str, 0, len + 1);
	WideCharToMultiByte(CP_ACP, 0, wstr, -1, str, len, NULL, NULL);
	if (wstr) delete[] wstr;
	return str;
}

//����ַ����еĿո�
void ClearSpace(string& s)
{
	int index = 0;
	if (!s.empty())
	{
		while ((index = s.find(' ', index)) != string::npos)
		{
			s.erase(index, 1);
		}
	}
}

//���ַ������Ϊ90
void FillNop(string& s)
{
	for (int i = 0; i < s.length() - 1; i += 2)
	{
		s[i] = '9';
		s[i + 1] = '0';
	}
}

bool IsFileExisted(FILE* pFile, const char* szSrc)
{
	fseek(pFile, 0, SEEK_SET);

	char szBuff[0x1024] = {};
	while (fgets(szBuff, 0x1000, pFile))
	{
		if (strcmp(szBuff, szSrc) == 0)
		{
			return true;
		}
		memset(szBuff, 0, 0x1024);
	}
	return false;
}

