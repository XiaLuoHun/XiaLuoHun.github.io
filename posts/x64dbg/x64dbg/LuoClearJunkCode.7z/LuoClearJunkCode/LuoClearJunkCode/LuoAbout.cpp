#include "LuoAbout.h"

HWND g_LuoAboutDialog = NULL;

INT_PTR CALLBACK AboutDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CLOSE:
	{
		DestroyWindow(hwndDlg);
		g_LuoAboutDialog = NULL;
		return true;
	}
	default:
		break;
	}

	return false;
}

void centerWindow(HWND window);

void ShowAboutDialog(HINSTANCE instance)
{
	if (!g_LuoAboutDialog)
	{
		g_LuoAboutDialog = CreateDialog(instance, MAKEINTRESOURCE(IDD_ABOUT), GuiGetWindowHandle(), AboutDialogProc);
	}

	ShowWindow(g_LuoAboutDialog, SW_SHOW);
	centerWindow(g_LuoAboutDialog);
}

void CloseAboutialog()
{
	if (g_LuoAboutDialog)
	{
		SendMessage(g_LuoAboutDialog, WM_CLOSE, 0, 0);
	}

	g_LuoAboutDialog = NULL;
}

