#pragma once
#include "pluginmain.h"
#include "resource.h"

#include "Common.h"

void ShowClearJunkDialog(HINSTANCE instance, duint dStart, duint dSize);

void CloseClearJunkDialog();

void AddFeature(HWND hwndDlg);

void ClearJunkCode(HWND hwndDlg);

void ClearDisasmCode(const char* searchpattern);

void ClearJunkCodeByFile(HWND hwndDlg);
