import frida
import sys

jscode = """
Java.perform(function(){
    //下面这一句代码是指定要Hook的so文件名和要Hook的函数名，函数名就是上面IDA导出表中显示的那个函数名
    Interceptor.attach(Module.findExportByName("libluojni.so","Java_org_example_luojni_MainActivity_LuoString"),{
        onEnter: function(args) {
            send("Hook start");
            send("args[2]=" + args[2]);
        },
        onLeave: function(retval){
            send("return:"+retval); //打印返回值
            var env = Java.vm.getEnv(); //获取env对象，也就是native函数的第一个参数
            var jstrings = env.newStringUtf("LuoHun");
            retval.replace(jstrings); //替换返回值
        }
    });
});
"""
def printMessage(message,data):
    if message['type'] == 'send':
        print(' {0}'.format(message['payload']))
    else:
        print(message)

process = frida.get_remote_device().attach('LuoJni')
script = process.create_script(jscode)
script.on('message',printMessage)
script.load()
sys.stdin.read()