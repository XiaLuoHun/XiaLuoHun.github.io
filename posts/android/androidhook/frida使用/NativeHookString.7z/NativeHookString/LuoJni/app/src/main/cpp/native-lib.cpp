#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_org_example_luojni_MainActivity_LuoString(JNIEnv *env, jobject thiz) {
    // TODO: implement LuoString()
    return  env->NewStringUTF("Luo HelloWorld!");
}