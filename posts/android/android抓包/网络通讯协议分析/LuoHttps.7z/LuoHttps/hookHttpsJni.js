var sslGetFdPtr = null
var SSL_get_sessionPtr = null
var SSL_SESSION_get_idPtr = null
var sslGetFd = null
var SSL_get_session = null
var SSL_SESSION_get_id = null

function initializeGlobals() {
    sslGetFdPtr = Module.getExportByName("libssl.so", "SSL_get_rfd");
    SSL_get_sessionPtr = Module.getExportByName("libssl.so", "SSL_get_session")
    SSL_SESSION_get_idPtr = Module.getExportByName("libssl.so", "SSL_SESSION_get_id")

    sslGetFd = new NativeFunction(sslGetFdPtr, 'int', ['pointer'])
    SSL_get_session = new NativeFunction(SSL_get_sessionPtr, "pointer", ["pointer"])
    SSL_SESSION_get_id = new NativeFunction(SSL_SESSION_get_idPtr, "pointer", ["pointer", "pointer"])
}

function getSslSessionId(ssl) {
    var session = SSL_get_session(ssl);
    if (session == 0) {
        return 0;
    }
    var len = Memory.alloc(4);
    var p = SSL_SESSION_get_id(session, len);
    len = Memory.readU32(len);
    var session_id = "";
    for (var i = 0; i < len; i++) {
        // Read a byte, convert it to a hex string (0xAB ==> "AB"), and append
        // it to session_id.
        session_id +=
            ("0" + Memory.readU8(p.add(i)).toString(16).toUpperCase()).substr(-2);
    }
    return session_id;
}

function getPortsAndAddresses(sockfd, isRead) {
    var message = {}
    var src_dst = ["src", "dst"]
    for (var i = 0; i < src_dst.length; i++) {
        if ((src_dst[i] == "src") ^ isRead) {
            var sockAddr = Socket.localAddress(sockfd)
        } else {
            var sockAddr = Socket.peerAddress(sockfd)
        }
        if (sockAddr == null) {
            // 网络超时or其他原因可能导致socket被关闭
            message[src_dst[i] + "_port"] = 0
            message[src_dst[i] + "_addr"] = 0
        } else {
            message[src_dst[i] + "_port"] = (sockAddr.port & 0xFFFF)
            message[src_dst[i] + "_addr"] = sockAddr.ip.split(":").pop()
        }
    }
    return message['src_addr'] + ':' + message['src_port'] + ' --> ' + message['dst_addr'] + ':' + message['dst_port']
}

function hookSSLWrite() {
    var SSL_write = Module.findExportByName("libssl.so", "SSL_write")
    Interceptor.attach(SSL_write, {
        onEnter: function (args) {
            var sslPtr = args[0]
            var buf = args[1]
            var num = args[2]

            //打印SSLSessionID
            var sslSessionID = getSslSessionId(sslPtr)
            console.log('SSL Session:', sslSessionID)

            //打印数据包的源和目标地址
            var sockfd = sslGetFd(sslPtr)
            var msg = getPortsAndAddresses(sockfd, false)
            console.log('[SSL_write] ', msg)

            //打印发包内容
            console.log(hexdump(buf, {
                length: num.toUInt32()
            }));

            //打印调用栈
            console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()));
        },
        onLeave: function (ret) {
            //console.log('SSL_write ret', ret)
        }
    })
}

function hookSSLRead() {
    var SSL_read = Module.findExportByName("libssl.so", "SSL_read")
    Interceptor.attach(SSL_read, {
        onEnter: function (args) {
            this.sslPtr = args[0];
            this.buf = args[1];
            var num = args[2];
            //console.log('SSL_read num', num)
        },
        onLeave: function (ret) {
            //console.log('SSL_read ret', ret)
            if (ret.toInt32() > -1) {
                //打印SSLSessionID
                var sslSessionID = getSslSessionId(this.sslPtr)
                console.log('SSL Session:', sslSessionID)

                //打印数据包的源和目标地址
                var sockfd = sslGetFd(this.sslPtr)
                var msg = getPortsAndAddresses(sockfd, true)
                console.log('[SSL_read]', msg)

                //打印收包内容
                console.log(hexdump(this.buf, {
                    length: ret.toUInt32()
                }));

                //打印调用栈
                console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()));
            }
        }
    })
}

function hookSSLJni() {
    initializeGlobals()
    hookSSLWrite()
    hookSSLRead()
}

setImmediate(hookSSLJni())