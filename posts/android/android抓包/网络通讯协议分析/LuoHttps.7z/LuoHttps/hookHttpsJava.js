function getAddrInfo(socket, isRead) {
    var src_addr = ''
    var src_port = ''
    var dst_addr = ''
    var dst_port = ''

    if (isRead) {
        src_addr = socket.getRemoteSocketAddress().toString().split(":")[0].split("/").pop()
        src_port = socket.getRemoteSocketAddress().toString().split(":").pop()
        dst_addr = socket.getLocalAddress().toString().split(":")[0].split("/").pop()
        dst_port = socket.getLocalPort().toString()
    } else {
        src_addr = socket.getLocalAddress().toString().split(":")[0].split("/").pop()
        src_port = socket.getLocalPort().toString()
        dst_addr = socket.getRemoteSocketAddress().toString().split(":")[0].split("/").pop()
        dst_port = socket.getRemoteSocketAddress().toString().split(":").pop()
    }
    return src_addr + ':' + src_port + ' --> ' + dst_addr + ':' + dst_port
}

function hookSSLOutputStream() {
    //com.android.org.conscrypt.ConscryptFileDescriptorSocket$SSLOutputStream.write
    Java.use('com.android.org.conscrypt.ConscryptFileDescriptorSocket$SSLOutputStream').write.overload('[B', 'int', 'int').implementation = function (buf, offset, byteCount) {
        var result = this.write(buf, offset, byteCount)
        //console.log('result', result, 'offset', offset, 'byteCount', byteCount)

        //打印数据包的源和目标地址
        var socket = this.this$0.value.socket.value
        var msg = getAddrInfo(socket, false)
        console.log('SSLOutputStream.write', msg)

        //打印发包内容
        var ptr = Memory.alloc(byteCount);
        for (var i = 0; i < byteCount; ++i)
            Memory.writeS8(ptr.add(i), buf[offset + i]);
        console.log(hexdump(ptr, {
            offset: 0,
            length: byteCount,
            header: false,
            ansi: false
        }));

        return result
    }
}

function hookSSLInputStream() {
    //com.android.org.conscrypt.ConscryptFileDescriptorSocket$SSLInputStream.read
    Java.use('com.android.org.conscrypt.ConscryptFileDescriptorSocket$SSLInputStream').read.overload('[B', 'int', 'int').implementation = function (buf, offset, byteCount) {
        var result = this.read(buf, offset, byteCount)

        //打印数据包的源和目标地址
        var socket = this.this$0.value.socket.value
        var msg = getAddrInfo(socket, true)
        console.log('SSLOutputStream.read', msg)

        //打印收包内容
        var ptr = Memory.alloc(result);
        for (var i = 0; i < result; ++i)
            Memory.writeS8(ptr.add(i), buf[offset + i]);
        console.log(hexdump(ptr, {
            offset: 0,
            length: result,
            header: false,
            ansi: false
        }));

        return result
    }
}

function hookSSLWrite() {
    var NativeCrypto = Java.use("com.android.org.conscrypt.NativeCrypto")
    NativeCrypto.SSL_write.implementation = function (sslNativePointer, fd, shc, b, off, len, writeTimeoutMillis) {
        var result = this.SSL_write(sslNativePointer, fd, shc, b, off, len, writeTimeoutMillis)
        //console.log('result', result, 'off', off, 'len', len)

        console.log('NativeCrypto.SSL_write:')

        //打印发包内容
        var bufLen = len
        var ptr = Memory.alloc(bufLen);
        for (var i = 0; i < bufLen; ++i)
            Memory.writeS8(ptr.add(i), b[off + i]);
        console.log(hexdump(ptr, {
            offset: 0,
            length: bufLen,
            header: false,
            ansi: false
        }));

        //打印堆栈调用
        console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()))
        return result
    }
}

function hookSSLRead() {
    var NativeCrypto = Java.use("com.android.org.conscrypt.NativeCrypto")
    NativeCrypto.SSL_read.implementation = function (sslNativePointer, fd, shc, b, off, len, writeTimeoutMillis) {
        var result = this.SSL_read(sslNativePointer, fd, shc, b, off, len, writeTimeoutMillis)
        //console.log('result', result, 'off', off, 'len', len)

        console.log('NativeCrypto.SSL_read:')

        //打印收包内容
        var bufLen = result
        var ptr = Memory.alloc(bufLen);
        for (var i = 0; i < bufLen; ++i)
            Memory.writeS8(ptr.add(i), b[off + i]);
        console.log(hexdump(ptr, {
            offset: 0,
            length: bufLen,
            header: false,
            ansi: false
        }));

        //打印堆栈调用
        console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()))
        return result
    }
}

function hookSSL() {
    Java.perform(function () {
        hookSSLOutputStream()
        hookSSLInputStream()
        //hookSSLWrite()
        //hookSSLRead()
    })
}

setImmediate(hookSSL())