function hookDatagramPacketInit() {
    var DatagramPacket = Java.use('java.net.DatagramPacket')
    DatagramPacket.$init.overload('[B', 'int', 'java.net.InetAddress', 'int').implementation = function (buf, length, address, port) {
        console.log('IP:', address.toString(), 'Port:', port)
        var result = this.$init(buf, length, address, port)
        //console.log('IP:', this.address.value.toString(), 'Port:', this.port.value)
        return result
    }
}

function hookUdpSend() {
    var linux = Java.use("libcore.io.Linux")
    linux.sendtoBytes.overload('java.io.FileDescriptor', 'java.lang.Object', 'int', 'int', 'int', 'java.net.InetAddress', 'int').implementation = function (fd, byteAry, byteOffset, byteCount, flags, inetAddress, port) {
        //打印数据包的源和目标地址
        var sockname = this.getsockname(fd)
        //console.log('sockname', JSON.stringify(sockname))
        var InetSocketAddressObj = Java.cast(sockname, Java.use("java.net.InetSocketAddress"))
        var src_addr = InetSocketAddressObj.holder.value.addr.value.toString()
        var src_port = InetSocketAddressObj.holder.value.port.value
        var dst_addr = inetAddress.toString()
        var dst_port = port
        var msg = src_addr + ':' + src_port + ' --> ' + dst_addr + ':' + dst_port
        console.log('sendtoBytes', msg)

        //打印发包内容
        var b = Java.array("byte", byteAry);
        var bufLen = byteCount
        var ptr = Memory.alloc(bufLen);
        for (var i = 0; i < bufLen; ++i)
            Memory.writeS8(ptr.add(i), b[byteOffset + i]);
        console.log(hexdump(ptr, {
            offset: 0,
            length: bufLen,
            header: false,
            ansi: false
        }));

        //打印调用栈
        console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()))
        return this.sendtoBytes(fd, byteAry, byteOffset, byteCount, flags, inetAddress, port)
    }

    linux.sendtoBytes.overload('java.io.FileDescriptor', 'java.lang.Object', 'int', 'int', 'int', 'java.net.SocketAddress').implementation = function (fd, byteAry, byteOffset, byteCount, flags, address) {
        return this.sendtoBytes(fd, byteAry, byteOffset, byteCount, flags, address);
    }
}

function hookUdpRecv() {
    var linux = Java.use("libcore.io.Linux")
    linux.recvfromBytes.implementation = function (fd, buffer, byteOffset, byteCount, flags, srcAddress) {
        var result = this.recvfromBytes(fd, buffer, byteOffset, byteCount, flags, srcAddress)
        //打印数据包的源和目标地址
        var src_addr = srcAddress.holder.value.addr.value.toString()
        var src_port = srcAddress.holder.value.port.value
        var sockname = this.getsockname(fd)
        //console.log('sockname', JSON.stringify(sockname))
        var InetSocketAddressObj = Java.cast(sockname, Java.use("java.net.InetSocketAddress"))
        var dst_addr = InetSocketAddressObj.holder.value.addr.value.toString()
        var dst_port = InetSocketAddressObj.holder.value.port.value
        var msg = src_addr + ':' + src_port + ' --> ' + dst_addr + ':' + dst_port
        console.log('recvfromBytes', msg)

        //打印收包内容
        var b = Java.array("byte", buffer);
        var ptr = Memory.alloc(result);
        for (var i = 0; i < result; ++i)
            Memory.writeS8(ptr.add(i), b[byteOffset + i]);
        console.log(hexdump(ptr, {
            offset: 0,
            length: result,
            header: false,
            ansi: false
        }));

        //打印调用栈
        console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()))
        return result
    }
}

function hookUdpJava() {
    Java.perform(function () {
        //hookDatagramPacketInit()
        //hookUdpSend()
        hookUdpRecv()
    })
}

setImmediate(hookUdpJava())