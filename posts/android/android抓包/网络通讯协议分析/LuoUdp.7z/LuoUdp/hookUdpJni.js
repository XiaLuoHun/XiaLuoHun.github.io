function hookJniSend() {
    var sendto = Module.getExportByName("libc.so", "sendto");
    Interceptor.attach(sendto, {
        onEnter: function (args) {
            var fd = args[0].toInt32()
            var buf = args[1]
            var n = args[2]
            var flags = args[3]
            var addr = args[4]
            var addr_len = args[5].toInt32()

            //打印Udp sendto的后两个参数
            // console.log(hexdump(addr, {
            //     length: addr_len
            // }))
            // console.log('len', addr_len)

            //打印数据包的源和目标地址
            var sockfd = fd
            var sockAddr = Socket.localAddress(sockfd)
            var src_addr = sockAddr.ip.split(":").pop()
            var src_port = (sockAddr.port & 0xFFFF)

            //解析sockaddr_in6结构
            var ipbase = ptr(addr).add(0x14);
            var dst_addr = ipbase.readU8() + "." + ipbase.add(1).readU8() + "." + ipbase.add(2).readU8() + "." + ipbase.add(3).readU8()
            var port_high = ptr(addr).add(2).readU8();
            var port_low = ptr(addr).add(3).readU8();
            var dst_port = port_high * 0x100 + port_low;

            var msg = src_addr + ':' + src_port + ' --> ' + dst_addr + ':' + dst_port
            console.log('sendto', msg)

            //打印发包内容
            var len = args[2].toInt32();
            console.log(hexdump(buf, {
                length: len
            }))

            //打印调用栈
            console.log('sendto called from:\n' +
                Thread.backtrace(this.context, Backtracer.FUZZY)
                .map(DebugSymbol.fromAddress).join('\n') + '\n')
        },
        onLeave: function (retval) {}
    })
}

function hookJniRecv() {
    var recvfrom = Module.getExportByName("libc.so", "recvfrom")
    Interceptor.attach(recvfrom, {
        onEnter: function (args) {
            this.fd = args[0].toInt32()
            this.buf = args[1]
            this.n = args[2]
            this.flags = args[3]
            this.addr = args[4]
            this.addr_len = args[5].toInt32()
        },
        onLeave: function (retval) {
            if (retval.toInt32() > -1) {
                //console.log('retval', retval)
                //打印Udp recvfrom
                // console.log(hexdump(this.addr, {
                //     length: 0x20
                // }))
                //console.log('len', this.addr_len)

                //打印数据包的源和目标地址
                var sockAddr = Socket.localAddress(this.fd)
                var dst_addr = sockAddr.ip
                var dst_port = (sockAddr.port & 0xFFFF)

                //解析sockaddr_in6结构
                var ipbase = ptr(this.addr).add(0x14);
                var src_addr = ipbase.readU8() + "." + ipbase.add(1).readU8() + "." + ipbase.add(2).readU8() + "." + ipbase.add(3).readU8()
                var porr_high = ptr(this.addr).add(2).readU8();
                var porr_low = ptr(this.addr).add(3).readU8();
                var src_port = porr_high * 0x100 + porr_low;

                var msg = src_addr + ':' + src_port + ' --> ' + dst_addr + ':' + dst_port
                console.log('recvfrom', msg)

                //打印收包内容
                console.log(hexdump(this.buf, {
                    length: retval.toInt32()
                }))

                //打印调用栈
                console.log('sendto called from:\n' +
                    Thread.backtrace(this.context, Backtracer.FUZZY)
                    .map(DebugSymbol.fromAddress).join('\n') + '\n')
            }


        }
    })

}

function hookUdpJni() {
    //hookJniSend()
    hookJniRecv()
}

setImmediate(hookUdpJni())