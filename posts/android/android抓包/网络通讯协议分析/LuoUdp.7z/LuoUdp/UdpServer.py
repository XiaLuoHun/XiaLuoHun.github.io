import socket
import threading

IP = '0.0.0.0'
PORT = 9997

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server.bind((IP, PORT))
    print(f'[*] bind on {IP}:{PORT}')

    while True:
        data, address = server.recvfrom(1024)
        print(f'[*] recvfrom connection from {address[0]}:{address[1]}')
        print(f'[*] Received: {data.decode("utf-8")}')
        server.sendto(b'ACKKK', address)

if __name__ == '__main__':
    main()
