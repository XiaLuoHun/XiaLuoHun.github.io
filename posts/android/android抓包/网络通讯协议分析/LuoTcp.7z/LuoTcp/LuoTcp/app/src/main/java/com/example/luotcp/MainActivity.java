package com.example.luotcp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.luotcp.databinding.ActivityMainBinding;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    static final String TAG = "XiaLuoHun";

    // Used to load the 'luotcp' library on application startup.
    static {
        System.loadLibrary("luotcp");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Example of a call to a native method
        TextView tv = binding.sampleText;
        tv.setText(stringFromJNI());

        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    while (true){
                        DoTcp("10.67.16.180", 9999);
                        Thread.sleep(3000);
                    }
                }
                catch(IOException | InterruptedException e){
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static void DoTcp(String strIP, int nPort) throws IOException, InterruptedException {
        Socket socket = new Socket(strIP, nPort);
        socket.setSoTimeout(10000);
        //发送数据给服务端
        OutputStream outputStream = socket.getOutputStream();
        outputStream.write("hello,server".getBytes("UTF-8"));
        Thread.sleep(2000);
        socket.shutdownOutput();
        //读取数据
        InputStream in = socket.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line = br.readLine();
        //打印读取到的数据
        Log.d(TAG, "tcp server recv:" + line);
        br.close();
        socket.close();
    }

    /**
     * A native method that is implemented by the 'luotcp' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}