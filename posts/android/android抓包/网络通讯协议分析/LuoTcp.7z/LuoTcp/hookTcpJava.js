function hookSocketInit() {
    var Socket = Java.use('java.net.Socket')
    // Socket.$init.overload('java.lang.String', 'int').implementation = function (host, port) {
    //     console.log('Host:', host, 'Port:', port)
    //     return this.$init(host, port)
    // }

    // Socket.$init.overload('[Ljava.net.InetAddress;', 'int', 'java.net.SocketAddress', 'boolean').implementation = function (addresses, port, localAddr, stream) {
    //     console.log('IP:', addresses[0].toString(), 'Port:', port)
    //     return this.$init(addresses, port, localAddr, stream)
    // }

    var InetSocketAddressHolder = Java.use('java.net.InetSocketAddress$InetSocketAddressHolder')
    InetSocketAddressHolder.$init.overload('java.lang.String', 'java.net.InetAddress', 'int').implementation = function (hostname, addr, port) {
        console.log('IP:', addr.toString(), 'Port:', port)
        //console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()));
        return this.$init(hostname, addr, port)
    }
}

function getAddrInfo(socket, isRead) {
    var src_addr = ''
    var src_port = ''
    var dst_addr = ''
    var dst_port = ''

    if (isRead) {
        src_addr = socket.getRemoteSocketAddress().toString().split(":")[0].split("/").pop()
        src_port = socket.getRemoteSocketAddress().toString().split(":").pop()
        dst_addr = socket.getLocalAddress().toString().split(":")[0].split("/").pop()
        dst_port = socket.getLocalPort().toString()
    } else {
        src_addr = socket.getLocalAddress().toString().split(":")[0].split("/").pop()
        src_port = socket.getLocalPort().toString()
        dst_addr = socket.getRemoteSocketAddress().toString().split(":")[0].split("/").pop()
        dst_port = socket.getRemoteSocketAddress().toString().split(":").pop()
    }

    return src_addr + ':' + src_port + ' --> ' + dst_addr + ':' + dst_port
}

function hookWrite() {
    var SocketOutputStream = Java.use('java.net.SocketOutputStream')
    SocketOutputStream.socketWrite0.implementation = function (fd, b, off, len) {
        //打印数据包的源和目标地址
        var socket = this.socket.value
        var msg = getAddrInfo(socket, false)
        console.log('socketWrite0', msg)

        //打印发包内容
        var bufLen = len
        var ptr = Memory.alloc(bufLen);
        for (var i = 0; i < bufLen; ++i)
            Memory.writeS8(ptr.add(i), b[off + i]);
        console.log(hexdump(ptr, {
            offset: 0,
            length: bufLen,
            header: false,
            ansi: false
        }));

        //打印调用栈
        console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()));

        return this.socketWrite0(fd, b, off, len)
    }
}

function hookRead() {
    var SocketInputStream = Java.use('java.net.SocketInputStream')
    SocketInputStream.socketRead0.implementation = function (fd, b, off, len, timeout) {
        var result = this.socketRead0(fd, b, off, len, timeout);
        if (result > 0) {
            //打印数据包的源和目标地址
            var socket = this.socket.value
            var msg = getAddrInfo(socket, true)
            console.log('socketRead0', msg)

            //打印收包内容
            var ptr = Memory.alloc(result);
            for (var i = 0; i < result; ++i)
                Memory.writeS8(ptr.add(i), b[off + i]);
            console.log(hexdump(ptr, {
                offset: 0,
                length: result,
                header: false,
                ansi: false
            }));

            //打印调用栈
            console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Throwable").$new()));
        }
        return result
    }
}

function hookTcpJava() {
    Java.perform(function () {
        //hookSocketInit()
        //hookWrite()
        hookRead()
    })
}

setImmediate(hookTcpJava())