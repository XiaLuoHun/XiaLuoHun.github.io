function getAddrInfo(sockfd, isRecv) {
    var message = {}
    var src_dst = ["src", "dst"]
    for (var i = 0; i < src_dst.length; i++) {
        if ((src_dst[i] == "src") ^ isRecv) {
            var sockAddr = Socket.localAddress(sockfd)
        } else {
            var sockAddr = Socket.peerAddress(sockfd)
        }
        if (sockAddr == null) {
            // 网络超时or其他原因可能导致socket被关闭
            message[src_dst[i] + "_port"] = 0
            message[src_dst[i] + "_addr"] = 0
        } else {
            message[src_dst[i] + "_port"] = (sockAddr.port & 0xFFFF)
            message[src_dst[i] + "_addr"] = sockAddr.ip.split(":").pop()
        }
    }
    return message['src_addr'] + ':' + message['src_port'] + ' --> ' + message['dst_addr'] + ':' + message['dst_port']
}

function hookJniSend() {
    var sendto = Module.getExportByName("libc.so", "sendto");
    Interceptor.attach(sendto, {
        onEnter: function (args) {
            //打印数据包的源和目标地址
            var sockfd = args[0].toInt32()
            var msg = getAddrInfo(sockfd, false)
            console.log('sendto', msg)

            //打印发包内容
            var buf = ptr(args[1]).readCString();
            var len = args[2].toInt32();
            console.log(hexdump(args[1], {
                length: len
            }))

            //打印调用栈
            console.log('sendto called from:\n' +
                Thread.backtrace(this.context, Backtracer.FUZZY)
                .map(DebugSymbol.fromAddress).join('\n') + '\n')
        },
        onLeave: function (retval) {}
    })
}

function hookJniRecv() {
    var recvfrom = Module.getExportByName("libc.so", "recvfrom");
    Interceptor.attach(recvfrom, {
        onEnter: function (args) {
            this.fd = args[0];
            this.buff = args[1];
            this.size = args[2];
        },
        onLeave: function (retval) {
            var type = Socket.type(this.fd.toInt32());
            if (retval > 0 && type != null && type != 'unix:stream') {
                //打印数据包的源和目标地址
                var sockfd = this.fd.toInt32()
                var msg = getAddrInfo(sockfd, true)
                console.log('recvfrom', msg)

                //打印收包内容
                console.log(hexdump(this.buff, {
                    length: retval.toInt32()
                }))

                //打印调用栈
                console.log('recvfrom called from:\n' +
                    Thread.backtrace(this.context, Backtracer.FUZZY)
                    .map(DebugSymbol.fromAddress).join('\n') + '\n')
            }
        }
    })
}

function hookTcpJni() {
    //hookJniSend()
    hookJniRecv()
}

setImmediate(hookTcpJni())