package com.example.luodst;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private static String TAG = "XiaLuoHun";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 定位发送请求按钮
        Button btn = findViewById(R.id.mybtn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 访问百度首页
                String requestUrl = "https://www.baidu.com/";
                okHttpExample myExample = new okHttpExample();
                try {
                    myExample.run(requestUrl);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}