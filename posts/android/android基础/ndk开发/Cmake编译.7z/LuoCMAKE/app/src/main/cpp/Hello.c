#include <stdio.h>
#include "mou1.h"

int main(){
	mou1();
	printf("Hello main\n");
	return 0;
}