#include "mou1.h"
#include "mou2.h"

int main(){
	mou1();
	mou2();
	printf("Hello Main\n");
	return 0;
}