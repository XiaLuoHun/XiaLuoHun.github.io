#include <stdio.h>

void mou2();