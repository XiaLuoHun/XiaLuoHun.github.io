#include <stdio.h>

void mou1();