#include <stdio.h>

int main(){
	printf("Hello Arm\n");
	return 0;
}