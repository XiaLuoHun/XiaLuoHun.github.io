#include <jni.h>
#include <string>

#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    printf("Main Start:%d\n", getpid());
    fflush(stdout);

    int childPid = fork();
    if (childPid == 0) {

        while (true) {
            sleep(1);
            printf("childPid: %d......\n", getpid());
            fflush(stdout);
        }

    } else {

        //附加子进程
        if (ptrace(PTRACE_ATTACH, childPid, 0, 0) < 0) {
            perror("PTRACE_ATTACH");
            fflush(stdout);
            return 0;
        }

        //等调试事件
        waitpid(childPid, NULL, WUNTRACED);
        printf("PTRACE_ATTACH OK\n");
        fflush(stdout);

        //继续执行
        if (ptrace(PTRACE_CONT, childPid, 0, 0) < 0) {
            perror("PTRACE_CONT");
            fflush(stdout);
            return 0;
        }
        printf("PTRACE_CONT OK\n");
        fflush(stdout);

    }

    //等待子进程结束
    waitpid(childPid, NULL, WUNTRACED);

    printf("Main End:%d\n", getpid());
    fflush(stdout);

    return 0;
}
