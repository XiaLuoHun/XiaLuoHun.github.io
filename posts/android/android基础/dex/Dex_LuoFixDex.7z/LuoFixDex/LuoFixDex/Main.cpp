
#include <stdio.h>
#include <stdlib.h>

#include "LuoFile.h"

#include "zlib.h"
#pragma comment(lib, "zlib/x86/lib/debug/zlibd.lib")

#include "sha/sha1.h"

int main() {

	char szDexPath[] = "C:/Users/XiaLuoHun/Desktop/Luo/classes.dex";

	LPVOID lpFileBuf = NULL;
	DWORD dwFileSize = LuoReadFile(szDexPath, &lpFileBuf);

	uLong adler = adler32(0L, Z_NULL, 0);
    adler = adler32(adler, (const Bytef*)((char*)lpFileBuf + 12), dwFileSize - 12);

	printf("checksum: %08x\n", adler);

    //��checksum
	memcpy((char*)lpFileBuf + 8, (char*)&adler, 4);

	//��signature
	unsigned char DigestOut[20] = {};
	SHA1_CTX context;
	SHA1Init(&context);
	SHA1Update(&context, (unsigned char*)lpFileBuf + 32, dwFileSize - 32);
	SHA1Final(DigestOut, &context);

	printf("signature ------------------\n");
	for (int i = 0; i < 20; i ++)
	{
		printf("%02X ", (unsigned char)DigestOut[i]);
	}
	printf("signature ------------------\n");

	memcpy((char*)lpFileBuf + 12, (char*)DigestOut, 20);



	MemoryToFile(lpFileBuf, dwFileSize, szDexPath);


	system("pause");
	return 0;
}
