#pragma once

#include <stdio.h>
#include <windows.h>

#define CLOSE_FILE(fp) if(fp){fclose(fp);fp=NULL;}

DWORD LuoReadFile(IN LPSTR lpszFile, OUT LPVOID * pFileBuffer);
BOOL MemoryToFile(IN LPVOID pMemBuffer, IN size_t size, OUT LPSTR lpszFile);