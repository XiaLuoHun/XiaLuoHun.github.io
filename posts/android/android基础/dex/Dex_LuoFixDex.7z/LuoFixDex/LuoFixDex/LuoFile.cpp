#include "LuoFile.h"

DWORD LuoReadFile(IN LPSTR lpszFile, OUT LPVOID* pFileBuffer)
{
	FILE* pFile;
	DWORD dwFileSize;
	pFile = fopen(lpszFile, "rb");
	if (pFile == NULL)
	{
		::MessageBox(NULL, "��PE�ļ�ʧ��", "Luo", MB_OK);
		return 0;
	}
	fseek(pFile, 0, SEEK_END);
	//�����ļ���С
	dwFileSize = ftell(pFile);
	fseek(pFile, 0, SEEK_SET);
	//����ռ�
	LPVOID pBuf = NULL;
	pBuf = malloc(dwFileSize);
	if (pBuf == NULL)
	{
		::MessageBox(NULL, "����ռ�ʧ��", "Luo", MB_OK);
		CLOSE_FILE(pFile);
		return 0;
	}
	memset(pBuf, 0, dwFileSize);
	size_t n = fread(pBuf, dwFileSize, 1, pFile);
	if (n == 0)
	{
		::MessageBox(NULL, "��ȡ�ļ�ʧ��", "Luo", MB_OK);
		fclose(pFile);
		free(pBuf);
		return 0;
	}

	*pFileBuffer = pBuf;
	pBuf = NULL;

	//�ر��ļ�
	fclose(pFile);
	return dwFileSize;
}

BOOL MemoryToFile(IN LPVOID pMemBuffer, IN size_t size, OUT LPSTR lpszFile)
{
	FILE* pFile;
	if (pMemBuffer == NULL)
	{
		OutputDebugString("MemoryToFile �ڴ滺����ָ����Ч!");
		return false;
	}
	pFile = fopen(lpszFile, "wb");
	if (pFile == NULL)
	{
		OutputDebugString("MemoryToFile ���ļ�ʧ��!");
		return false;
	}
	if (!fwrite(pMemBuffer, size, 1, pFile))
	{
		OutputDebugString("MemoryToFile д���ļ�ʧ��!");
		perror("fwrite");
		CLOSE_FILE(pFile);
		return false;
	}
	CLOSE_FILE(pFile);

	return true;
}