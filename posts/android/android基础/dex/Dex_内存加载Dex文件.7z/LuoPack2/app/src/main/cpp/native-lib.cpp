#include <jni.h>
#include <string>

#include <android/log.h>
#include <dlfcn.h>

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "Luo", __VA_ARGS__)

typedef const jlong (*OpenMemory)(const jbyte *base, size_t size,
                                  const std::string &location,
                                  uint32_t location_checksum,
                                  void* mem_map,
                                  std::string *error_msg);

#define kSHA1DigestLen 20
typedef uint8_t u1;
typedef uint16_t u2;
typedef uint32_t u4;
typedef uint64_t u8;
typedef int8_t s1;
typedef int16_t s2;
typedef int32_t s4;
typedef int64_t s8;

struct DexHeader {
    u1 magic[8];           /* includes version number */
    u4 checksum;           /* adler32 checksum */
    u1 signature[kSHA1DigestLen]; /* SHA-1 hash */
    u4 fileSize;           /* length of entire file */
    u4 headerSize;         /* offset to start of next section */
    u4 endianTag;
    u4 linkSize;
    u4 linkOff;
    u4 mapOff;
    u4 stringIdsSize;
    u4 stringIdsOff;
    u4 typeIdsSize;
    u4 typeIdsOff;
    u4 protoIdsSize;
    u4 protoIdsOff;
    u4 fieldIdsSize;
    u4 fieldIdsOff;
    u4 methodIdsSize;
    u4 methodIdsOff;
    u4 classDefsSize;
    u4 classDefsOff;
    u4 dataSize;
    u4 dataOff;
};


extern "C" JNIEXPORT jstring JNICALL
Java_org_example_luopack2_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}
extern "C"
JNIEXPORT jlong JNICALL
Java_org_example_luopack2_myApp_MemoryLoadDex(JNIEnv *env, jobject thiz, jbyteArray dex_buffer,
                                              jobject class_loader) {
    LOGD("MemoryLoadDex Begin");

    jboolean isCopy = true;
    jbyte *dexData = env->GetByteArrayElements(dex_buffer, &isCopy);

    LOGD("dexData = %p\n", dexData);

    //加载Dex
    void *handle = dlopen("libart.so", 0);
    if (!handle) {
        LOGD("dlopen error");
        return NULL;
    }

    //从I0出OpenMemory名称粉碎后的名字
    OpenMemory openMemory = (OpenMemory) dlsym(handle,
                                               "_ZN3art7DexFile10OpenMemoryEPKhjRKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEjPNS_6MemMapEPS9_");
    if (!openMemory) {
        LOGD("dlsym error");
        return NULL;
    }

    DexHeader *dexHeader = (DexHeader *) dexData;
    std::string strLocation = "";
    jlong dexFile = openMemory(dexData,
                               dexHeader->fileSize,
                               strLocation,
                               dexHeader->checksum,
                               NULL, NULL);
    if (dexFile == NULL){
        LOGD("openMemory error");
    }

    LOGD("MemoryLoadDex End");
    return dexFile;
}
