package org.example.luopack2;

import android.app.Application;
import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import dalvik.system.BaseDexClassLoader;
import dalvik.system.DexClassLoader;

public class myApp extends Application {

    static {
        System.loadLibrary("luopack2");
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

        loadDex(base);
    }

    public void loadDex(Context base) {
        byte[] dexBuffer = getDexByteBuffer("classes.dex");

        long cookie = MemoryLoadDex(dexBuffer, getClassLoader());

        //替换classLoader
        try {
            Class clsBaseDexClassLoader = BaseDexClassLoader.class;
            Field pathList = clsBaseDexClassLoader.getDeclaredField("pathList");
            pathList.setAccessible(true);
            Object objpathList = pathList.get(getClassLoader());

            Class clsDexPathList = Class.forName("dalvik.system.DexPathList");
            Field dexElements = clsDexPathList.getDeclaredField("dexElements");
            dexElements.setAccessible(true);
            Object[] objdexElements = (Object[]) dexElements.get(objpathList);
            Object objElement = objdexElements[0];

            Class clsDexPathList$Element = Class.forName("dalvik.system.DexPathList$Element");
            Field dexFile = clsDexPathList$Element.getDeclaredField("dexFile");
            dexFile.setAccessible(true);
            Object objDexFile = dexFile.get(objElement);

            Class clsDexFile = Class.forName("dalvik.system.DexFile");
            Field mCookie = clsDexFile.getDeclaredField("mCookie");
            mCookie.setAccessible(true);
            mCookie.set(objDexFile, cookie);


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public byte[] getDexByteBuffer(String strDex) {
        InputStream is = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            is = getAssets().open(strDex);
            byte[] buffer = new byte[0x1000];
            while (true) {
                int bytes = is.read(buffer);
                if (bytes <= 0) {
                    break;
                }
                bos.write(buffer, 0, bytes);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return bos.toByteArray();
    }

    public native long MemoryLoadDex(byte[] dexBuffer, ClassLoader classLoader);

}
