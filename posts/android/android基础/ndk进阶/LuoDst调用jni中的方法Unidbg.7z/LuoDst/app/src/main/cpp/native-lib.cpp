#include <jni.h>
#include <string>

#include "md5.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_luodst_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}
extern "C"
JNIEXPORT jint JNICALL
Java_com_example_luodst_MainActivity_LuoAdd(JNIEnv *env, jobject thiz, jint n1, jint n2) {
    return n1 + n2;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_luodst_MainActivity_mdString(JNIEnv *env, jclass clazz, jstring string) {
    const char *szString = env->GetStringUTFChars(string, NULL);
    std::string strMd5 = MD5(szString).toStr();

    return env->NewStringUTF(strMd5.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_luodst_MainActivity_Refmd5(JNIEnv *env, jobject thiz, jstring string) {
    jclass clsMainActivity = env->FindClass("com/example/luodst/MainActivity");
    jmethodID Javamd5 = env->GetMethodID(clsMainActivity, "Javamd5",
                                         "(Ljava/lang/String;)Ljava/lang/String;");
    jstring strMd5 = (jstring) env->CallObjectMethod(thiz, Javamd5, string);
    return strMd5;
}