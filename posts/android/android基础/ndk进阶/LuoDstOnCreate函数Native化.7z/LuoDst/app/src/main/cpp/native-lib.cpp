#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_luodst_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_luodst_MainActivity_onCreate(JNIEnv *env, jobject thiz,
                                              jobject saved_instance_state) {
    //super.onCreate(savedInstanceState);
    //方式一
    jclass clsAppCompatActivity1 = env->FindClass("androidx/appcompat/app/AppCompatActivity");
    //方式二
    jclass clsMainActivity = env->GetObjectClass(thiz);
    jclass clsAppCompatActivity2 = env->GetSuperclass(clsMainActivity);

    jmethodID onCreate = env->GetMethodID(clsAppCompatActivity1, "onCreate",
                                          "(Landroid/os/Bundle;)V");
    //调用父类方法
    env->CallNonvirtualVoidMethod(thiz, clsAppCompatActivity1, onCreate, saved_instance_state);

    //binding = ActivityMainBinding.inflate(getLayoutInflater());
    jmethodID getLayoutInflater = env->GetMethodID(clsMainActivity, "getLayoutInflater",
                                                   "()Landroid/view/LayoutInflater;");
    jclass clsActivityMainBinding = env->FindClass(
            "com/example/luodst/databinding/ActivityMainBinding");
    jmethodID inflate = env->GetStaticMethodID(clsActivityMainBinding, "inflate",
                                               "(Landroid/view/LayoutInflater;)Lcom/example/luodst/databinding/ActivityMainBinding;");
    jobject jbinding = env->CallStaticObjectMethod(clsActivityMainBinding, inflate,
                                                   env->CallObjectMethod(thiz, getLayoutInflater));

    //setContentView(binding.getRoot());
    jmethodID getRoot = env->GetMethodID(clsActivityMainBinding, "getRoot",
                                         "()Landroid/view/View;");
    jmethodID setContentView = env->GetMethodID(clsMainActivity, "setContentView",
                                                "(Landroid/view/View;)V");
    env->CallVoidMethod(thiz, setContentView, env->CallObjectMethod(jbinding, getRoot));

    //TextView tv = binding.sampleText;
    jfieldID sampleText = env->GetFieldID(clsActivityMainBinding, "sampleText",
                                          "Landroid/widget/TextView;");
    jobject tv = env->GetObjectField(jbinding, sampleText);

    //tv.setText(stringFromJNI());
    jclass clsTextView = env->FindClass("android/widget/TextView");
    jmethodID setText = env->GetMethodID(clsTextView, "setText", "(Ljava/lang/CharSequence;)V");
    jmethodID stringFromJNI = env->GetMethodID(clsMainActivity, "stringFromJNI",
                                               "()Ljava/lang/String;");
    env->CallVoidMethod(tv, setText, env->CallObjectMethod(thiz, stringFromJNI));
}