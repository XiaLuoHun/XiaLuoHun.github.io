#include <jni.h>
#include <string>

#include "md5.h"

#define NELEM(x) ((int) (sizeof(x) / sizeof((x)[0])))

jstring LuoNativeFunc(JNIEnv *env, jclass clazz, jstring string) {
    const char *szString = env->GetStringUTFChars(string, NULL);
    std::string strMd5 = MD5(szString).toStr();

    return env->NewStringUTF(strMd5.c_str());
}

static JNINativeMethod method_table[] = {
        {"mdString", "(Ljava/lang/String;)Ljava/lang/String;", (void *) LuoNativeFunc},
};

static int registerMethods(JNIEnv *env, const char *className,
                           JNINativeMethod *gMethods, int numMethods) {
    jclass clazz = env->FindClass(className);
    if (clazz == nullptr) {
        return JNI_FALSE;
    }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env = nullptr;
    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    // 注册native方法
    if (!registerMethods(env, "com/example/luomd5/MainActivity", method_table,
                         NELEM(method_table))) {
        return JNI_ERR;
    }

    return JNI_VERSION_1_6;
}