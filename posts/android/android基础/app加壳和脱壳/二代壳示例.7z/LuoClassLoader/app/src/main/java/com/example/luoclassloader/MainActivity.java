package com.example.luoclassloader;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.luoclassloader.databinding.ActivityMainBinding;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;

public class MainActivity extends AppCompatActivity {
    private final String TAG = "[LuoHun] ";

    // Used to load the 'luoclassloader' library on application startup.
    static {
        System.loadLibrary("luoclassloader");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //二代壳
        SecondShell();

        //反射运行抽空的方法
        tstDexClassLoader(getApplicationContext(), "/data/local/tmp/2.dex");
    }

    public void tstDexClassLoader(Context context, String strDexFilePath) {
        File optFile = context.getDir("opt_dex", 0);
        File libFile = context.getDir("lib_dex", 0);

        DexClassLoader dexClassLoader = new DexClassLoader(strDexFilePath,
                optFile.getAbsolutePath(),
                libFile.getAbsolutePath(),
                context.getClassLoader());

        Class clazz = null;
        try {
            clazz = dexClassLoader.loadClass("com.example.luodst.LuoTst");
            Object object = clazz.newInstance();
            Method func1Method = clazz.getDeclaredMethod("fun1");
            func1Method.invoke(object);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

    }

    public native void SecondShell();
}