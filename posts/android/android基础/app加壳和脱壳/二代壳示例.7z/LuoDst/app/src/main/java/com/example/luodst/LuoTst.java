package com.example.luodst;

import android.util.Log;

public class LuoTst {
    private final String TAG = "[LuoHun] ";

    public void fun1() {
        Log.d(TAG, "org.example.luodst.fun1");
    }
}