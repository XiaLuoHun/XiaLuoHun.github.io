#include <jni.h>
#include <string>


extern "C"
JNIEXPORT jint JNICALL
Java_org_example_luojni_MainActivity_LuoAdd(JNIEnv *env, jobject thiz, jint n1, jint n2) {
    // TODO: implement LuoAdd()
    return n1 + n2;
}