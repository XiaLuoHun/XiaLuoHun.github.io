import frida
import sys

jscode = """
Java.perform(function(){
    //下面这一句代码是指定要Hook的so文件名和要Hook的函数名，函数名就是上面IDA导出表中显示的那个函数名
    Interceptor.attach(Module.findExportByName("libluojni.so","Java_org_example_luojni_MainActivity_LuoAdd"),{
        //onEnter: function(args)顾名思义就是进入该函数前要执行的代码，其中args是传入的参数，一般so层函数第一个参数都是JniEnv，第二个参数是jclass，从第三个参数开始才是我们java层传入的参数
        onEnter: function(args) {
            send("Hook start");
            send("args[2]=" + args[2]); //打印我们java层第一个传入的参数
            send("args[3]=" + args[3]); //打印我们java层传入的第二个参数
        },
        onLeave: function(retval){ //onLeave: function(retval)是该函数执行结束要执行的代码，其中retval参数即是返回值
            send("return:"+retval); //打印返回值
            retval.replace(10); //替换返回值为10
        }
    });
});
"""
def printMessage(message,data):
    if message['type'] == 'send':
        print(' {0}'.format(message['payload']))
    else:
        print(message)

process = frida.get_remote_device().attach('LuoJni')
script = process.create_script(jscode)
script.on('message',printMessage)
script.load()
sys.stdin.read()