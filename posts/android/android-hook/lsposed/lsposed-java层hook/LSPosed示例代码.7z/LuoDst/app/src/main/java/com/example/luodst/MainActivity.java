package com.example.luodst;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.luodst.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private final String TAG = "[XiaLuoHun]";

    // Used to load the 'luodst' library on application startup.
    static {
        System.loadLibrary("luodst");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Example of a call to a native method
        TextView tv = binding.sampleText;
        tv.setText(stringFromJNI());

        Person person1 = new Person();
        Log.i(TAG, person1.toString());
        Person person2 = new Person("Luo", 50);
        Log.i(TAG, person2.toString());

        String personName = person2.getName(person1);
        Log.i(TAG, personName);

        String strResult = person2.replaceFunc();
        Log.i(TAG, strResult);
    }

    /**
     * A native method that is implemented by the 'luodst' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}