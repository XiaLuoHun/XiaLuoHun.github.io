package com.example.luodst;

public class Person {
    private String name = "LuoHun";
    private int age = 18;

    public Person(){
    }

    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }

    // Invoke
    public String publicMethod(){
        return String.format("publicMethod name:%s age:%d", this.name, this.age);
    }

    private String privateMethod(){
        return String.format("privateMethod name:%s age:%d", this.name, this.age);
    }

    public static String publicStaticMethod(){
        return "I'm from publicStaticMethod";
    }

    public String getName(Person person){
        return "Person name is " + person.name;
    }

    public String toString(){
        return String.format("name:%s age:%d", this.name, this.age);
    }

    public String replaceFunc(){
        return String.format("replaceFunc name:%s age:%d", this.name, this.age);
    }

    class Student{
        String course = "Math";
        public String getCourse(){
            return course;
        }
    }

}
