package com.example.luoxposeddemo;

import android.util.Log;

import java.lang.reflect.Field;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class LuoHook implements IXposedHookLoadPackage {
    private final String TAG = "[LuoXposed]";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (lpparam.packageName.equals("com.example.luodst")) {
            //寻找类 方式一
            //Class personClass = lpparam.classLoader.loadClass("com.example.luodst.Person");
            //寻找类 方式二
            Class personClass = XposedHelpers.findClass("com.example.luodst.Person",lpparam.classLoader);

            //进行函数替换
            XposedHelpers.findAndHookMethod(personClass, "replaceFunc", new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                    Log.i(TAG, "replaceFunc");
                    return "LuoReplaceFunc";
                }
            });
        }
    }
}