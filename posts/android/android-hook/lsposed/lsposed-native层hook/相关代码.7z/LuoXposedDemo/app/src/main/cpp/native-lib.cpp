#include <jni.h>
#include <string>
#include <dlfcn.h>
#include "LSPlant.h"
static HookFunType hook_func = nullptr;

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_luoxposeddemo_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

bool *(*back_check)(std::string strDst);
bool myCheck(std::string strDst){
    return true;
}

void on_library_loaded(const char *name, void *handle) {
    // hooks on `libluodst.so`
    if (std::string(name).compare("libluodst.so")) {
        void *target = dlsym(handle, "check");
        hook_func(target, (void *) myCheck, (void **) &back_check);
    }
}

extern "C" [[gnu::visibility("default")]] [[gnu::used]]
jint JNI_OnLoad(JavaVM *jvm, void*) {
    JNIEnv *env = nullptr;
    jvm->GetEnv((void **)&env, JNI_VERSION_1_6);

    //hook_func((void *)env->functions->FindClass, (void *)fake_FindClass, (void **)&backup_FindClass);
    return JNI_VERSION_1_6;
}

extern "C" [[gnu::visibility("default")]] [[gnu::used]]
NativeOnModuleLoaded native_init(const NativeAPIEntries *entries) {
    hook_func = entries->hook_func;
    // system hooks
    //hook_func((void*) fopen, (void*) fake_fopen, (void**) &backup_fopen);
    return on_library_loaded;
}

