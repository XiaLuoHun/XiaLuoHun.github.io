package com.example.luoxposeddemo;

import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class LuoHook implements IXposedHookLoadPackage {
    private final String TAG = "[LuoXposed]";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (lpparam.packageName.equals("com.example.luodst")) {
            Log.i(TAG, "Enter Hook");
            try {
                System.loadLibrary("luoxposeddemo");
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
