#include <jni.h>
#include <string>

#include <android/log.h>
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "LuoHun", __VA_ARGS__);
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "LuoHun", __VA_ARGS__);
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "LuoHun", __VA_ARGS__);


extern "C" bool check(std::string strDst){
    return strstr(strDst.c_str(), "Luo");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_luodst_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {

    if (check("Hun")){
        LOGE("check true")
    } else{
        LOGE("check false")
    }

    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}