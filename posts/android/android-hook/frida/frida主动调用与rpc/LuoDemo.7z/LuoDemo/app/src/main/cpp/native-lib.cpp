#include <jni.h>
#include <string>

#include "aes_utils.h"
#include "tools.h"
#include "junk.h"

#define NELEM(x) ((int) (sizeof(x) / sizeof((x)[0])))

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_luodemo_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

jstring JNICALL method01(JNIEnv *env, jclass jcls, jstring str_) {
    if (str_ == nullptr) return nullptr;

    const char *str = env->GetStringUTFChars(str_, JNI_FALSE);
    char *result = AES_128_CBC_PKCS5_Encrypt(str);

    env->ReleaseStringUTFChars(str_, str);

    jstring jResult = getJString(env, result);
    free(result);

    return jResult;
}

JNIEXPORT jstring JNICALL method02(JNIEnv *env, jobject jcls, jstring str_) {
    if (str_ == nullptr) return nullptr;

    const char *str = env->GetStringUTFChars(str_, JNI_FALSE);
    char *result = AES_128_CBC_PKCS5_Decrypt(str);

    env->ReleaseStringUTFChars(str_, str);

    jstring jResult = getJString(env, result);
    free(result);

    return jResult;
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved){
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    JNINativeMethod methods[] = {
            {"method01", "(Ljava/lang/String;)Ljava/lang/String;", (void *) method01},
            {"method02", "(Ljava/lang/String;)Ljava/lang/String;", (void *) method02},
    };
    env->RegisterNatives(env->FindClass("com/example/luodemo/MainActivity"), methods, NELEM(methods));
    return JNI_VERSION_1_6;
}
