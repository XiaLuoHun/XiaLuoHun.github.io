package com.example.loaddex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.strictmode.WebViewMethodCalledOnWrongThreadViolation;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DexClassLoader dexLoader = new DexClassLoader("/data/local/tmp/mydex.dex",
                "/sdcard",
                "sdcard",
                MainActivity.class.getClassLoader());

        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Class myDexCls = dexLoader.loadClass("com.example.dexplugin.MyDex");
            /*        Method LuoTst = myDexCls.getDeclaredMethod("LuoTst");
                    LuoTst.setAccessible(true);*/

                    Method[] myMethods = myDexCls.getDeclaredMethods();
                    for (Method n : myMethods) {
                        if (n.getName().indexOf("LuoTst") >= 0) {
                            n.setAccessible(true);
                            String str = (String) n.invoke(null);
                            Log.d("loaddex", str);
                        }
                    }

                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException | InvocationTargetException e) {
                    e.printStackTrace();
                }
            }
        });

    }

}