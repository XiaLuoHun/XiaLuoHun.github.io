package com.example.dexplugin;

import android.util.Log;

public class MyDex {
    public static String LuoTst() {
        Log.d("LuoHun", "com.example.dexplugin.MyDex.LuoTst");
        return "Hello MyDex!";
    }
}
