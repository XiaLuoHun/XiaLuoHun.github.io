package org.example.luojni;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.example.luojni.databinding.ActivityMainBinding;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class MainActivity extends AppCompatActivity {

    public int mData = 10;


    // Used to load the 'luojni' library on application startup.
    static {
        System.loadLibrary("luojni");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //调用
        byte[] ary = new byte[]{10, 20, 30, 40, 50};
        fun1("Hello Jni", ary);
        fun2();


        //Java反射
        //拿目标对象
        //①
        // Class cls = MainActivity.class;
        //② 本身有对象
        //Class cls = this.getClass();
        //③ 常用, 通过类名拿
        try {
            Class cls = Class.forName("org.example.luojni.MainActivity");

            //new 对象
            //不带构造new对象
            Object obj = cls.newInstance();
            //带构造new对象
            Constructor constructor = cls.getConstructor();
            //传构造参数即可
            obj = constructor.newInstance(10);

            //调方法 传参数是为了防止有歧义,因为函数可以重载
            //①拿方法
            Method method = cls.getMethod("MyAdd", int.class, int.class);
            //②拿方法 修改方法的访问权限 当方法为private时 第①种方式会拿不到
            method = cls.getDeclaredMethod("MyAdd", int.class, int.class);
            //修改方法的访问权限
            method.setAccessible(true);
            //为了统一 返回值为Object
            //如果为静态方法 第一个参数给null就可以了
            Object ret = method.invoke(obj, 1, 2);
            //若返回值为整型 就转为整型的包装类
            int nResult = ((Integer) ret).intValue();

            //反射字段
            //①拿字段
            Field field = cls.getField("mData");
            //②拿字段 修改字段的访问权限 当字段为private时 第①种方式会拿不到
            field = cls.getDeclaredField("mData");
            //修改字段的访问权限
            field.setAccessible(true);
            //修改字段值
            field.setInt(obj, 1);
            //获取字段值
            nResult = field.getInt(obj);


        } catch (ClassNotFoundException | NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }

    }

    public int MyAdd(int n1, int n2) {
        return n1 + n2;
    }

    //函数声明
    public native String fun1(String str, byte[] ary);

   public native void fun2();
}