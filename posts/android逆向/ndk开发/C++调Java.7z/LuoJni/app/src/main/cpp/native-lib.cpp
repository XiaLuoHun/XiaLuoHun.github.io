#include <jni.h>
#include <string>
#include <android/log.h>
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "Luo", __VA_ARGS__);

extern "C"
JNIEXPORT jstring JNICALL
Java_org_example_luojni_MainActivity_fun1(JNIEnv *env,
                                          jobject thiz,
                                          jstring str,
                                          jbyteArray ary) {
    //操作Java中的字符串
    int nLen = env->GetStringLength(str);
    //传false 说明不拷贝缓冲区,跟Java中用的是同一个缓冲区
    jboolean flag = false;
    const char* psz = env->GetStringUTFChars(str, &flag);
    LOGD("len = %d str = %s\n", nLen, psz);

   //操作Java中的数组
   int nCount = env->GetArrayLength(ary);
   jbyte * p = env->GetByteArrayElements(ary, &flag);
    for (int i = 0; i < nCount; ++i) {
        LOGD("%d ", p[i]);
    }

   //返回String
    return  env->NewStringUTF("Hello Ret");
}

//参数信息描述
//I(int) F(float) D(double) J(long) Z(bool) C(char) S(short) Ljava/lang/String(String)
//一维数组 [i(int[])
//二维数组 [[i(int[][])

extern "C"
JNIEXPORT void JNICALL
Java_org_example_luojni_MainActivity_fun2(JNIEnv *env, jobject thiz) {
    //反射
    //拿Java类
    jclass cls = env->FindClass("org/example/luojni/MyClass");

    //new对象
    //传"<init>" 就是拿构造
    jmethodID construct = env->GetMethodID(cls, "<init>", "()V");
    //构造若是有参数就传参, 这个函数是不定参的
    jobject obj = env->NewObject(cls, construct);

    //调方法
    //非静态方法
    //()V 括号内写参数 后面写返回值
    jmethodID fun1 = env->GetMethodID(cls, "fun1", "()V");
    env->CallVoidMethod(obj, fun1);
    //静态方法
    jmethodID fun2 = env->GetStaticMethodID(cls, "fun2", "()V");
    env->CallStaticVoidMethod(cls, fun2);
    //示例
    jmethodID Add = env->GetMethodID(cls, "Add", "(II)I");
    //检查Java中的异常
    if (env->ExceptionCheck()){
        //打印异常栈信息
        env->ExceptionDescribe();
        //清除异常信息 为了不让程序崩
        env->ExceptionClear();
        return;
    }
    jint nRet = env->CallIntMethod(obj, Add, 1, 6);

    //修改字段
    jfieldID mData =  env->GetFieldID(cls, "mData", "I");
    env->SetIntField(obj, mData, 200);

    //引用计数 我们在C++中New了一个对象 Java虚拟机如何知道何时释放对象
    //释放字符串或数组对象 可以调env->Release...
    env->DeleteLocalRef(obj);
}