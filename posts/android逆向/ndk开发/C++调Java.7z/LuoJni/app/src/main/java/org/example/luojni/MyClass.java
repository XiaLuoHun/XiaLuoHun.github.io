package org.example.luojni;

import android.util.Log;

public class MyClass {
    private String TAG = "[Luo] MyClass.";
    private int mData = 100;

    void fun1(){
        Log.d(TAG, "fun1");
    }

    static void fun2(){
        Log.d("[Luo] MyClass.", "fun2:Static");
    }


    int Add(int n1, int n2){
        return n1 + n2;
    }

}
