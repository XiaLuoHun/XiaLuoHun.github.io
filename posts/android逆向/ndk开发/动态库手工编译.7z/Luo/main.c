
#include "mou1.h"

int main(){
	mou1();
	printf("Hello Main\n");
}