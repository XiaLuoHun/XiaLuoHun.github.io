#include "mou2.h"

void mou2(){
	printf("Hello mou2\n");
}