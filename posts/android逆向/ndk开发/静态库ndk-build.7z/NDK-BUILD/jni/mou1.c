#include "mou1.h"

void mou1(){
	printf("Hello mou1\n");
}