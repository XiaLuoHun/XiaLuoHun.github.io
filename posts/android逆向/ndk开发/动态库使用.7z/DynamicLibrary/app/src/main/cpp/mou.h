
#ifdef __cplusplus
extern "C"{
#endif

void mou1();
void mou2();

#ifdef __cplusplus
};
#endif

