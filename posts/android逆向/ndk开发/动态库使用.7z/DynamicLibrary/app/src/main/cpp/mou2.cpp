//
// Created by XiaLuoHun on 2021/8/8.
//
#include "mou.h"
#include <stdio.h>

void mou2(){
    printf("Hello mou2\n");
}

