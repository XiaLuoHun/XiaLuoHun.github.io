#include "mou.h"
#include <stdio.h>

__attribute__ ((visibility("hidden"))) void mou1(){
	printf("Hello mou1\n");
}

//初始化函数无需导出
extern "C" __attribute__ ((visibility("hidden"))) void _init(){
	printf("_init\n");
}

//反初始化函数也无需导出
extern "C"  __attribute__ ((visibility("hidden"))) void _fini(){
	printf("_fini\n");
}

//构造函数
__attribute__ ((visibility("hidden"))) __attribute__ ((constructor)) void MyLoad1(){
	printf("MyLoad1\n");
}

__attribute__ ((visibility("hidden"))) __attribute__ ((constructor)) void MyLoad2(){
	printf("MyLoad2\n");
}

//析构函数
__attribute__ ((visibility("hidden"))) __attribute__ ((destructor)) void MyUnLoad1(){
	printf("MyLoad1\n");
}

__attribute__ ((visibility("hidden"))) __attribute__ ((destructor)) void MyUnLoad2(){
	printf("MyLoad2\n");
}