import frida  #导入frida模块
import sys    #导入sys模块

jscode = """
    Java.perform(function(){  
        var MainActivity = Java.use('org.example.luodst.MainActivity');
        MainActivity.TstMethod.implementation = function(){
            send('Statr! Hook!');
            return 'Luo Hun!'
        }
    });
"""

def on_message(message,data):
    print(message)

#当前Frida版本为15.1.8
#下方attach中的内容具体以 frida-ps -U 中显示的为准
#目前填写apk的包名会显示 unable to find process with name
process = frida.get_remote_device().attach("LuoDst")
script = process.create_script(jscode)
script.on('message',on_message)
script.load()
sys.stdin.read()