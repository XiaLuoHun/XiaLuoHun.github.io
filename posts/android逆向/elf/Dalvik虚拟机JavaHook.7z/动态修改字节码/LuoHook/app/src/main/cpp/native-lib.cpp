#include <jni.h>
#include <string>
#include <android/log.h>
#include <sys/mman.h>

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "LuoHun", __VA_ARGS__);

//访问权限
enum {
    ACC_PUBLIC       = 0x00000001,       // class, field, method, ic
    ACC_PRIVATE      = 0x00000002,       // field, method, ic
    ACC_PROTECTED    = 0x00000004,       // field, method, ic
    ACC_STATIC       = 0x00000008,       // field, method, ic
    ACC_FINAL        = 0x00000010,       // class, field, method, ic
    ACC_SYNCHRONIZED = 0x00000020,       // method (only allowed on natives)
    ACC_SUPER        = 0x00000020,       // class (not used in Dalvik)
    ACC_VOLATILE     = 0x00000040,       // field
    ACC_BRIDGE       = 0x00000040,       // method (1.5)
    ACC_TRANSIENT    = 0x00000080,       // field
    ACC_VARARGS      = 0x00000080,       // method (1.5)
    ACC_NATIVE       = 0x00000100,       // method
    ACC_INTERFACE    = 0x00000200,       // class, ic
    ACC_ABSTRACT     = 0x00000400,       // class, method, ic
    ACC_STRICT       = 0x00000800,       // method
    ACC_SYNTHETIC    = 0x00001000,       // field, method, ic
    ACC_ANNOTATION   = 0x00002000,       // class, ic (1.5)
    ACC_ENUM         = 0x00004000,       // class, field, ic (1.5)
    ACC_CONSTRUCTOR  = 0x00010000,       // method (Dalvik only)
    ACC_DECLARED_SYNCHRONIZED =
    0x00020000,       // method (Dalvik only)
    ACC_CLASS_MASK =
    (ACC_PUBLIC | ACC_FINAL | ACC_INTERFACE | ACC_ABSTRACT
     | ACC_SYNTHETIC | ACC_ANNOTATION | ACC_ENUM),
    ACC_INNER_CLASS_MASK =
    (ACC_CLASS_MASK | ACC_PRIVATE | ACC_PROTECTED | ACC_STATIC),
    ACC_FIELD_MASK =
    (ACC_PUBLIC | ACC_PRIVATE | ACC_PROTECTED | ACC_STATIC | ACC_FINAL
     | ACC_VOLATILE | ACC_TRANSIENT | ACC_SYNTHETIC | ACC_ENUM),
    ACC_METHOD_MASK =
    (ACC_PUBLIC | ACC_PRIVATE | ACC_PROTECTED | ACC_STATIC | ACC_FINAL
     | ACC_SYNCHRONIZED | ACC_BRIDGE | ACC_VARARGS | ACC_NATIVE
     | ACC_ABSTRACT | ACC_STRICT | ACC_SYNTHETIC | ACC_CONSTRUCTOR
     | ACC_DECLARED_SYNCHRONIZED),
};

typedef unsigned char        u1;
typedef unsigned short       u2;
typedef unsigned int         u4;
typedef unsigned long long   u8;
typedef signed char          s1;
typedef signed short         s2;
typedef signed int           s4;
typedef signed long long     s8;
struct Object;

union JValue {
    u1      z;
    s1      b;
    u2      c;
    s2      s;
    s4      i;
    s8      j;
    float   f;
    double  d;
    Object* l;
};

struct DexProto {
    const void *dexFile;     /* file the idx refers to */
    u4 protoIdx;                /* index into proto_ids table of dexFile */
};

struct Method;
typedef void (*DalvikBridgeFunc)(const u4* args, JValue* pResult,
                                  Method* method, struct Thread* self);
struct Method {
    void*              clazz;
    u4                 accessFlags;
    u2                 methodIndex;
    u2                 registersSize;
    u2                 outsSize;
    u2                 insSize;
    const char*        name;
    DexProto           prototype;
    const char*        shorty;
    const u2*          insns;         //字节码
    int                jniArgInfo;
    DalvikBridgeFunc   nativeFunc;    //jni方法
    bool               fastJni;
    bool               noRef;
    bool               shouldTrace;
    const void*        registerMap;
    bool               inProfile;
};

void FakeAdd(const u4* args, JValue* pResult,
                         Method* method, struct Thread* self){
    LOGD("FakeAdd");
    LOGD("%p %p %d %d %d", args[0],args[1],args[2], args[3],args[4] );

    //2个参数在args[2], args[3]
    //返回值为int
    pResult ->i = args[2] - args[3];
}

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    LOGD("JNI_OnLoad");

    JNIEnv *env = NULL;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    LOGD("env = %p", env);

    jclass clsMainActivity = env->FindClass("org/example/luohook/MainActivity");
    LOGD("clsMainActivity:%p", clsMainActivity);

    jmethodID Construct = env->GetMethodID(clsMainActivity, "<init>", "()V");
    jobject objMainActivity = env->NewObject(clsMainActivity, Construct);

    jmethodID MyAdd = env->GetMethodID(clsMainActivity, "MyAdd", "(II)I");
    LOGD("MyAdd:%p", MyAdd);

    Method *meth = (Method *) MyAdd;
    LOGD("name:%s shorty:%s insns:%p", meth->name, meth->shorty, meth->insns);

    int nRet = env->CallIntMethod(objMainActivity, MyAdd, 3, 5);
    LOGD("3 + 5 = %d", nRet);

 /*   //修改方式1
    //修改内存保护属性
    if (mprotect((void *) ((long long) meth->insns & ~0xfff),
                 0x1000,
                 PROT_WRITE | PROT_READ) < 0) {
        perror("mprotect");
    }
    //可以修改meth->insns指向的字节码,也可以将meth->insns指向的地址给换掉
    u2 *pCode = (u2 *) malloc(10);
    pCode[0] = 0x0091;
    pCode[1] = 0x0302;
    pCode[2] = 0x000f;
    meth->insns = pCode;*/

    //修改方式2
    //访问权限加上Native方法,告诉操作系统这是个jni函数
    meth->accessFlags |= ACC_NATIVE;
    //修改Native地址
    meth->nativeFunc = FakeAdd;

    nRet = env->CallIntMethod(objMainActivity, MyAdd, 3, 5);
    LOGD("3 + 5 = %d", nRet);

    return JNI_VERSION_1_6;
}