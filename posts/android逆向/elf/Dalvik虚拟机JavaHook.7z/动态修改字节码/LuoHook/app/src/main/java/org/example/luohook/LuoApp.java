package org.example.luohook;

import android.app.Application;

public class LuoApp extends Application {
    static {
        System.loadLibrary("luohook");
    }
}
