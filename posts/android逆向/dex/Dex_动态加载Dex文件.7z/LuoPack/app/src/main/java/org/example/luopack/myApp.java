package org.example.luopack;

import android.app.Application;
import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;

public class myApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

        loadDex(base);
    }

    public void loadDex(Context base) {
        //释放Dex文件
        String dexFilePath = ReleaseFile(base, "classes.dex", "mydex");
        String odexFilePath = createFolder(base, "myodex");

        DexClassLoader classLoader = new DexClassLoader(dexFilePath, odexFilePath,
                getApplicationInfo().nativeLibraryDir, getClassLoader());

        //getClassLoader(), 拿的是当前类加载器, 里面没有org.example.luosrc.MainActivity这个类
        //上述新new的classLoader里面有org.example.luosrc.MainActivity这个类
        //让Android操作系统使用上述新new的classLoader即可

        //反射替换classLoader
        //getClassLoader(), F7进去查看在哪里拿的classLoader
        //ContextImpl这个类中
        try {
            Class clsContextImpl = Class.forName("android.app.ContextImpl");
            Field mPackageInfo = clsContextImpl.getDeclaredField("mPackageInfo");
            mPackageInfo.setAccessible(true);
            Object objLoadApk = mPackageInfo.get(getBaseContext());
            Class clsLoadApk = Class.forName("android.app.LoadedApk");
            Field mClassLoader = clsLoadApk.getDeclaredField("mClassLoader");
            mClassLoader.setAccessible(true);
            mClassLoader.set(objLoadApk, classLoader);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    String createFolder(Context base, String strAndroidFolder) {
        File dir = base.getFilesDir();
        File fileDir = new File(dir.getAbsoluteFile() + "/" + strAndroidFolder);
        if (!fileDir.exists()) {
            fileDir.mkdir();
        }

        return fileDir.getAbsolutePath();
    }

    //将要释放的文件放到assets目录下
    String ReleaseFile(Context base, String strFileName, String strAndroidFolder) {
        InputStream is = null;
        FileOutputStream fos = null;
        File dexFile = null;
        try {
            is = getAssets().open(strFileName);
            File dir = base.getFilesDir();
            File fileDir = new File(dir.getAbsoluteFile() + "/" + strAndroidFolder);
            if (!fileDir.exists()) {
                fileDir.mkdir();
            }
            dexFile = new File(fileDir.getAbsoluteFile() + "/" + strFileName);
            fos = new FileOutputStream(dexFile);
            byte[] buffer = new byte[0x1000];
            while (true) {
                int bytes = is.read(buffer);
                if (bytes <= 0) {
                    break;
                }
                fos.write(buffer, 0, bytes);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return dexFile.getAbsolutePath();
        }
    }

}
