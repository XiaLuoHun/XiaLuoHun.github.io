﻿
// LuoDstDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "LuoDst.h"
#include "LuoDstDlg.h"
#include "afxdialogex.h"

#include <tlhelp32.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

// CLuoDstDlg 对话框

CLuoDstDlg::CLuoDstDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_LUODST_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLuoDstDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CLuoDstDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(BTN_INJECT, &CLuoDstDlg::OnBnClickedInject)
	ON_BN_CLICKED(BTN_EXIT, &CLuoDstDlg::OnBnClickedExit)
END_MESSAGE_MAP()


// CLuoDstDlg 消息处理程序

BOOL CLuoDstDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CLuoDstDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CLuoDstDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CLuoDstDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

BOOL CLuoDstDlg::InjectDllBySetWindowsHook(ULONG32 ulTargetProcessID, char* pszDllName)
{
	m_hmDll = LoadLibrary(pszDllName);
	if (NULL == m_hmDll)
	{
		MessageBox("LoadLibraryError!");
		return FALSE;
	}

	HOOKPROC sub_address = NULL;
	sub_address = (HOOKPROC)GetProcAddress(m_hmDll, "MyMessageProcess");
	if (NULL == sub_address)
	{
		MessageBox("GetProcAddressError!");
		return FALSE;
	}

	DWORD dwThreadID = GetThreadID(ulTargetProcessID);

	/*
		参数1:要安装的挂钩类型
		参数2:指定系统调用的窗口消息处理函数
		参数3:标示一个包含窗口处理消息函数(参数2)的DLL
		参数4:安装挂钩的线程ID
	*/
	m_hHook = SetWindowsHookEx(WH_KEYBOARD,
		sub_address,
		m_hmDll,
		dwThreadID);

	if (m_hHook != NULL) {
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

DWORD CLuoDstDlg::GetThreadID(ULONG32 ulTargetProcessID)
{
	HANDLE Handle = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
	if (Handle != INVALID_HANDLE_VALUE)
	{
		THREADENTRY32 te;
		te.dwSize = sizeof(te);
		if (Thread32First(Handle, &te))
		{
			do
			{
				if (te.dwSize >= FIELD_OFFSET(THREADENTRY32, th32OwnerProcessID) + sizeof(te.th32OwnerProcessID))
				{
					if (te.th32OwnerProcessID == ulTargetProcessID)
					{
						HANDLE hThread = OpenThread(READ_CONTROL, FALSE, te.th32ThreadID);
						if (!hThread)
						{
							//MessageBox("Couldn't get thread handle!");
						}
						else
						{
							return te.th32ThreadID;
						}
					}
				}
			} while (Thread32Next(Handle, &te));
		}
	}
	CloseHandle(Handle);
	return (DWORD)0;
}

DWORD CLuoDstDlg::GetPIdByProcessName(const char* pszProcessName)
{
	DWORD id = 0;
	//获得系统快照句柄 (得到当前的所有进程)   
	HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 pInfo; //用于保存进程信息的一个数据结构   
	pInfo.dwSize = sizeof(pInfo);
	//从快照中获取进程列表   
	Process32First(hSnapShot, &pInfo); //从第一个进程开始循环   
	do
	{
		//这里的 pszProcessName 为你的进程名称   
		//strcmp(_strlwr(_strdup(pInfo.szExeFile)), pszProcessName) == 0
		if (strcmp(pInfo.szExeFile, pszProcessName) == 0)
		{
			id = pInfo.th32ProcessID;
			break;
		}
	} while (Process32Next(hSnapShot, &pInfo) != FALSE);
	return id;
}

//HHOOK g_hHook;
//LRESULT CALLBACK MyKeyboardProc(int code,// hook code
//	WPARAM wParam,  // virtual-key code
//	LPARAM lParam   // keystroke-message information
//)
//{
//	//MSDN说明,如果code < 0,必须返回,CallNextHookEx的返回值
//	if (code < 0)
//	{
//		return CallNextHookEx(g_hHook, code, wParam, lParam);
//	}
//	CString csFmt;
//	csFmt.Format("Hook：%c ", wParam);
//	OutputDebugString(csFmt);
//
//	//把消息传递给下一个钩子
//	return CallNextHookEx(g_hHook, code, wParam, lParam);
//}

void CLuoDstDlg::OnBnClickedInject()
{
	////设置局部钩子
	//g_hHook = ::SetWindowsHookEx(
	//	WH_KEYBOARD, //键盘钩子
	//	MyKeyboardProc, //钩子回调函数
	//	NULL, //局部钩子,填NULL;全局钩子,填DLL的模块句柄
	//	GetCurrentThreadId() //钩本线程的窗口;填NULL则勾所有窗口线程
	//);

	//获取被注入进程名
	char szInjectProcess[MAX_PATH] = {};
	GetDlgItemText(EDT_INJECTNAME, szInjectProcess, MAX_PATH);

	DWORD dwProcessId = GetPIdByProcessName(szInjectProcess);

	//获取注入的DLL
	char szDllName[MAX_PATH] = { 0 };
	GetDlgItemText(EDT_INJECTDLL, szDllName, MAX_PATH);
	BOOL bRet = InjectDllBySetWindowsHook((ULONG32)dwProcessId, szDllName);
	if (bRet)
	{
		MessageBox("注入成功");
	}
}

void CLuoDstDlg::OnBnClickedExit()
{
	if (m_hHook) {
		UnhookWindowsHookEx(m_hHook);
		m_hHook = NULL;
	}
		
	if (m_hmDll) {
		FreeLibrary(m_hmDll);
		m_hmDll = NULL;
	}
}
