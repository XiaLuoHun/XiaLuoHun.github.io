#include <stdlib.h>
#include <stdio.h>
#include <Windows.h>
#include <TlHelp32.h>
#include <tchar.h>

DWORD GetPidByPname(char* pszProcessName)
{
	DWORD id = 0;
	//���ϵͳ���վ�� (�õ���ǰ�����н���)   
	HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 pInfo; //���ڱ��������Ϣ��һ�����ݽṹ   
	pInfo.dwSize = sizeof(pInfo);
	//�ӿ����л�ȡ�����б�   
	Process32First(hSnapShot, &pInfo); //�ӵ�һ�����̿�ʼѭ��   
	do
	{
		//����� pszProcessName Ϊ��Ľ�������   
		//strcmp(_strlwr(_strdup(pInfo.szExeFile)), pszProcessName) == 0
		if (strcmp(pInfo.szExeFile, pszProcessName) == 0)
		{
			id = pInfo.th32ProcessID;
			break;
		}
	} while (Process32Next(hSnapShot, &pInfo) != FALSE);
	return id;
}


BOOL GetAllTidByPid(DWORD dwProcessId, DWORD** ppThreadId, DWORD* pdwThreadIdLength)
{
	DWORD* pThreadId = NULL;
	DWORD dwThreadIdLength = 0;
	DWORD dwBuffLength = 1000;
	THREADENTRY32 te32 = { 0 };
	HANDLE hSnapShot = NULL;
	BOOL bRet = TRUE;

	do
	{
		//�����ڴ�
		pThreadId = new DWORD[dwBuffLength];
		if (pThreadId == NULL)
		{
			bRet = FALSE;
			break;
		}
		else
		{
		}
		RtlZeroMemory(pThreadId, (dwBuffLength * sizeof(DWORD)));

		//��ȡ�߳̿���
		RtlZeroMemory(&te32, sizeof(te32));
		te32.dwSize = sizeof(te32);
		hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
		if (hSnapShot == NULL)
		{
			bRet = FALSE;
			break;
		}
		else
		{
		}

		//��ȡ��һ�����յ���Ϣ
		bRet = Thread32First(hSnapShot, &te32);
		while (bRet)
		{
			//��ȡ���̶�Ӧ���߳�ID
			if (te32.th32OwnerProcessID == dwProcessId)
			{
				pThreadId[dwThreadIdLength] = te32.th32ThreadID;
				dwThreadIdLength++;
			}
			//������һ���߳̿�����Ϣ
			bRet = Thread32Next(hSnapShot, &te32);
		}
		//����
		*ppThreadId = pThreadId;
		*pdwThreadIdLength = dwThreadIdLength;
		bRet = TRUE;

	} while (FALSE);

	if (FALSE == bRet)
	{
		if (pThreadId)
		{
			delete[] pThreadId;
			pThreadId = NULL;
		}
	}
	return bRet;
}

BOOL APCInject(char* pszProcessName, char* pszDllName)
{
	BOOL bRet = FALSE;
	DWORD dwProcessId = 0;
	DWORD* pThreadId = NULL;
	DWORD dwThreadIdLength = 0;
	HANDLE hProcess = NULL;
	HANDLE hThread = NULL;
	PVOID pBaseAddress = NULL;
	PVOID pLoadLibraryAFunc = NULL;
	SIZE_T dwRet = 0;
	DWORD dwDllPathLen = strlen(pszDllName) + 1;
	DWORD i = 0;

	do
	{
		//���ݽ������ƻ�ȡPID
		dwProcessId = GetPidByPname(pszProcessName);
		if (0 >= dwProcessId)
		{
			bRet = FALSE;
			break;
		}
		else
		{
		}
		//����PID
		bRet = GetAllTidByPid(dwProcessId, &pThreadId, &dwThreadIdLength);
		if (bRet == FALSE)
		{
			
			bRet = FALSE;
			break;
		}
		else
		{
		}

		//��ע�����
		hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
		if (hProcess == NULL)
		{
		
			bRet = FALSE;
			break;
		}
		else
		{
		}
		//��ע��Ľ��̿ռ������ڴ�
		pBaseAddress = VirtualAllocEx(hProcess, NULL, dwDllPathLen, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
		if (pBaseAddress == NULL)
		{
			
			bRet = FALSE;
			break;
		}
		else
		{
		}
		//������Ŀռ���д��DLL·������
		WriteProcessMemory(hProcess, pBaseAddress, pszDllName, dwDllPathLen, &dwRet);
		if (dwRet != dwDllPathLen)
		{
			
			bRet = FALSE;
			break;
		}
		else
		{
		}

		//��ȡLoadLibrary�ĵ�ַ
		pLoadLibraryAFunc = GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");
		if (pLoadLibraryAFunc == NULL)
		{
			
			bRet = FALSE;
			break;
		}
		else
		{
		}

		//�����߳� ����APC
		for (i = 0; i < dwThreadIdLength; i++)
		{
			//���߳�
			hThread = OpenThread(THREAD_ALL_ACCESS, FALSE, pThreadId[i]);
			if (hThread)
			{
				//����APC
				QueueUserAPC((PAPCFUNC)pLoadLibraryAFunc, hThread, (ULONG_PTR)pBaseAddress);
				//�ر��߳̾��
				CloseHandle(hThread);
				hThread = NULL;
			}
		}
		bRet = TRUE;
	} while (FALSE);

	//�ͷ��ڴ�
	if (hProcess)
	{
		CloseHandle(hProcess);
		hProcess = NULL;
	}
	if (hThread)
	{
		delete[] pThreadId;
		pThreadId = NULL;
	}
	return bRet;
}

int main() {

	TCHAR szDllPath[MAX_PATH] = { 0 };
	GetCurrentDirectory(MAX_PATH, szDllPath);
	_tcscat(szDllPath, TEXT("\\LuoDll.dll"));

	APCInject("Clover.exe", szDllPath);

	system("pause");
	return 0;
}
