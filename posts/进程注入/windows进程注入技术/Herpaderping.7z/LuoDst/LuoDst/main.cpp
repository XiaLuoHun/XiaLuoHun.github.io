

#include <stdlib.h>
#include <stdio.h>
#include <Windows.h>

BOOL WINAPI WinMain(__in HINSTANCE hInstance, __in_opt HINSTANCE hPrevInstance, __in LPSTR lpCmdLine, __in int nShowCmd) {

	::MessageBox(NULL, "LuoDst", "Inject Succsee!", MB_OK);
}