#include "LuoFile.h"

DWORD LuoReadFile(IN LPSTR lpszFile, OUT LPVOID* pFileBuffer)
{
	FILE* pFile;
	DWORD dwFileSize;
	pFile = fopen(lpszFile, "rb");
	if (pFile == NULL)
	{
		return 0;
	}
	fseek(pFile, 0, SEEK_END);
	//�����ļ���С
	dwFileSize = ftell(pFile);
	fseek(pFile, 0, SEEK_SET);
	//����ռ�
	LPVOID pBuf = NULL;
	pBuf = malloc(dwFileSize);
	if (pBuf == NULL)
	{
		CLOSE_FILE(pFile);
		return 0;
	}
	memset(pBuf, 0, dwFileSize);
	size_t n = fread(pBuf, dwFileSize, 1, pFile);
	if (n == 0)
	{
		fclose(pFile);
		free(pBuf);
		return 0;
	}

	*pFileBuffer = pBuf;
	pBuf = NULL;

	//�ر��ļ�
	fclose(pFile);
	return dwFileSize;
}

BOOL MemoryToFile(IN LPVOID pMemBuffer, IN size_t size, OUT LPSTR lpszFile)
{
	FILE* pFile;
	if (pMemBuffer == NULL)
	{
		return false;
	}
	pFile = fopen(lpszFile, "w+b");
	if (pFile == NULL)
	{
		return false;
	}
	if (!fwrite(pMemBuffer, size, 1, pFile))
	{
		CLOSE_FILE(pFile);
		return false;
	}
	CLOSE_FILE(pFile);

	return true;
}