IAT patcher
============
Main application source.
