#include <stdio.h>
#include <windows.H>
int main(int argc, char* argv[])
{
	char szBuf[8];
	FILE* fp = NULL;

	fp = fopen("pwd.txt", "r+");
	fscanf(fp, "%s", szBuf);

	if (strcmp(szBuf, "Hello") == 0)
	{
		printf("ok\r\n");
	}
	else
	{
		printf("error\r\n");
	}

	fclose(fp);
	return 0;
}